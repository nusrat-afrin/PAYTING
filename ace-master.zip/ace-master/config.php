<?php
$conn = mysql_connect("localhost","root","password");
//$conn = mysql_connect("http://192.168.1.6:83","root","");
//mysql_select_db("dev_payting",$conn);
mysql_select_db("dev_payting",$conn);
/*session_start();
$message="";

$conn = mysql_connect("localhost","root","password");
//$conn = mysql_connect("http://192.168.1.6:83","root","password");
//mysql_select_db("dev_payting",$conn);
mysql_select_db("dev_payting",$conn);*/
?>