									<div class="col-xs-12 col-sm-6 widget-container-col ui-sortable">
										<div class="widget-box ui-sortable-handle">
											<div class="widget-header">
												<h5 class="widget-title">Collections</h5>

												<div class="widget-toolbar">
													<div class="widget-menu">
														<a href="#" data-action="settings" data-toggle="dropdown">
															<i class="ace-icon fa fa-bars"></i>
														</a>

														<ul class="dropdown-menu dropdown-menu-right dropdown-light-blue dropdown-caret dropdown-closer">
															<li>
																<a data-toggle="tab" href="#dropdown1">Option#1</a>
															</li>

															<li>
																<a data-toggle="tab" href="#dropdown2">Option#2</a>
															</li>
														</ul>
													</div>

													<a href="#" data-action="fullscreen" class="orange2">
														<i class="ace-icon fa fa-expand"></i>
													</a>

													<a href="#" data-action="reload">
														<i class="ace-icon fa fa-refresh"></i>
													</a>

													<a href="#" data-action="collapse">
														<i class="ace-icon fa fa-chevron-up"></i>
													</a>

													<a href="#" data-action="close">
														<i class="ace-icon fa fa-times"></i>
													</a>
												</div>
											</div>

											<div class="widget-body">
												<div class="widget-main">
													<div class="col-xs-4" align="center">
													<?php 
									                $sql7sum="Select SUM(INVOICE_VALUE) as INVOICE_VALUE FROM ncl_invoices where DATETIME > DATE_SUB(CURDATE(), INTERVAL 7 DAY) 
									                AND MERCHANT_ID=$_SESSION[ID]";
									                //echo $sqlsum;
									                $data7=mysql_fetch_array(mysql_query($sql7sum));
									                ?>
									              		<div>Last 7 days</div>
														<div><?php echo $data7['INVOICE_VALUE'];?></div>
												
									              <?php 
									                $sql15sum="Select SUM(INVOICE_VALUE) as INVOICE_VALUE FROM ncl_invoices where DATETIME > DATE_SUB(CURDATE(), INTERVAL 15 DAY) 
									                AND MERCHANT_ID=$_SESSION[ID]";
									                //echo $sqlsum;
									                $data15=mysql_fetch_array(mysql_query($sql15sum));
									                ?>
									                <div>Last 15 days</div>
									                <div><?php echo $data15['INVOICE_VALUE'];?></div>
									              <?php 
									                $sql30sum="Select SUM(INVOICE_VALUE) as INVOICE_VALUE FROM ncl_invoices where DATETIME > DATE_SUB(CURDATE(), INTERVAL 30 DAY) 
									                AND MERCHANT_ID=$_SESSION[ID]";
									                //echo $sqlsum;
									                $data30=mysql_fetch_array(mysql_query($sql30sum));
									                ?>
									                <div>Last 30 days</div>
									                <div><?php echo $data30['INVOICE_VALUE'];?></div>
									              	</div>
													<p align="right"><a href="dashboard.php">Details</a></p>
												</div>
											</div>
										</div>
									</div>