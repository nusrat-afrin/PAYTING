<?php 
session_start();
include('config.php');
$result = mysql_query("SELECT * FROM ncl_merchant_users where ID=$_SESSION[ID]");
//echo "SELECT * FROM ncl_merchant_users where ID=$_SESSION[ID]";
$row  = mysql_fetch_array($result);
//echo "<br>"."$row";
//echo strtoupper($row["NAME"]);

?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
		<meta charset="utf-8" />
		<title>Merchant Admin</title>

		<meta name="description" content="Dynamic tables and grids using jqGrid plugin" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0" />

		<!-- bootstrap & fontawesome -->
		<link rel="stylesheet" href="assets/css/bootstrap.min.css" />
		<link rel="stylesheet" href="assets/font-awesome/4.2.0/css/font-awesome.min.css" />

		<!-- page specific plugin styles -->
		<link rel="stylesheet" href="assets/css/jquery-ui.min.css" />
		<link rel="stylesheet" href="assets/css/datepicker.min.css" />
		<link rel="stylesheet" href="assets/css/ui.jqgrid.min.css" />

		<!-- text fonts -->
		<link rel="stylesheet" href="assets/fonts/fonts.googleapis.com.css" />

		<!-- ace styles -->
		<link rel="stylesheet" href="assets/css/ace.min.css" class="ace-main-stylesheet" id="main-ace-style" />

		<!--[if lte IE 9]>
			<link rel="stylesheet" href="assets/css/ace-part2.min.css" class="ace-main-stylesheet" />
		<![endif]-->

		<!--[if lte IE 9]>
		  <link rel="stylesheet" href="assets/css/ace-ie.min.css" />
		<![endif]-->

		<!-- inline styles related to this page -->

		<!-- ace settings handler -->
		<script src="assets/js/ace-extra.min.js"></script>

		<!-- HTML5shiv and Respond.js for IE8 to support HTML5 elements and media queries -->

		<!--[if lte IE 8]>
		<script src="assets/js/html5shiv.min.js"></script>
		<script src="assets/js/respond.min.js"></script>
		<![endif]-->
	
<!--JQuery Grid Data -->
<link rel="stylesheet" href="styles/jqx.base.css" type="text/css" />
<link rel="stylesheet" href="styles/jqx.classic.css" type="text/css" />
<script type="text/javascript" src="js/jquery-1.11.1.min.js"></script>
<script type="text/javascript" src="js/jqxcore.js"></script>
<script type="text/javascript" src="js/jqxbuttons.js"></script>
<script type="text/javascript" src="js/jqxscrollbar.js"></script>
<script type="text/javascript" src="js/jqxmenu.js"></script>
<script type="text/javascript" src="js/jqxdata.js"></script>
<script type="text/javascript" src="js/jqxgrid.js"></script>

<!--<link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">-->
<script src="//code.jquery.com/jquery-1.10.2.js"></script>
<link rel="stylesheet" type="text/css" href="assets/css/styles.css" />
<script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
<link rel="stylesheet" type="text/css" href="assets/css/tcal.css" />
<script type="text/javascript" src="assets/js/tcal.js"></script>
<script src="https://code.jquery.com/jquery-2.0.2.min.js" integrity="sha256-TZWGoHXwgqBP1AF4SZxHIBKzUdtMGk0hCQegiR99itk=" crossorigin="anonymous"></script>
<!--
  <link rel="stylesheet" href="/resources/demos/style.css">
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script> -->
  <!--<script>
  $(function() {
    $( "#fromdate" ).datepicker();
    $( "#todate" ).datepicker();
  });
  </script>-->
  <script type="text/javascript">
    function printData()
    {
       alert(Hi);
       var divToPrint=document.getElementById("printTable");
       newWin= window.open("");
       newWin.document.write(divToPrint.outerHTML);
       newWin.print();
       newWin.close();
    }

    $('button').on('click',function(){
    printData();
    })
  </script>
  <script type="text/javascript"> 
    function Today() 
    { 
      var today = new Date();
      alert(today); 
    }
    function Yesterday() 
    {       
      var yesterday = new Date();
      yesterday ; //# => Fri Apr 01 2011 11:14:50 GMT+0200 (CEST)
      yesterday.setDate(yesterday.getDate() - 1);
      yesterday ; //# => Thu Mar 31 2011 11:14:50 GMT+0200 (CEST)
      alert(yesterday);
      /*var today = new Date();
      //subtract milliseconds representing one day from current date
      //var yesterday = new Date(today - 24*60*60*1000);
      var yesterday = today-1;//today.setDate(today.getDate()-1);
      alert(yesterday); */
    }
    function Search() 
    {       
      var fromdate = document.getElementById("fromdate");
      alert(fromdate);

    }
  </script>
	</head>
	<body class="no-skin">
		<div id="navbar" class="navbar navbar-default">
			<script type="text/javascript">
				try{ace.settings.check('navbar' , 'fixed')}catch(e){}
			</script>

			<div class="navbar-container" id="navbar-container">
				<button type="button" class="navbar-toggle menu-toggler pull-left" id="menu-toggler" data-target="#sidebar">
					<span class="sr-only">Toggle sidebar</span>

					<span class="icon-bar"></span>

					<span class="icon-bar"></span>

					<span class="icon-bar"></span>
				</button>

				<div class="navbar-header pull-left">
					<a href="index.html" class="navbar-brand">
						<small>
							<i class="fa fa-leaf"></i>
							Merchant Admin
						</small>
					</a>
				</div>

				<div class="navbar-buttons navbar-header pull-right" role="navigation">
					<ul class="nav ace-nav">
						<li class="grey">
							<a data-toggle="dropdown" class="dropdown-toggle" href="#">
								<i class="ace-icon fa fa-tasks"></i>
								<span class="badge badge-grey">4</span>
							</a>

							<ul class="dropdown-menu-right dropdown-navbar dropdown-menu dropdown-caret dropdown-close">
								<li class="dropdown-header">
									<i class="ace-icon fa fa-check"></i>
									4 Tasks to complete
								</li>

								<li class="dropdown-content">
									<ul class="dropdown-menu dropdown-navbar">
										<li>
											<a href="#">
												<div class="clearfix">
													<span class="pull-left">Software Update</span>
													<span class="pull-right">65%</span>
												</div>

												<div class="progress progress-mini">
													<div style="width:65%" class="progress-bar"></div>
												</div>
											</a>
										</li>

										<li>
											<a href="#">
												<div class="clearfix">
													<span class="pull-left">Hardware Upgrade</span>
													<span class="pull-right">35%</span>
												</div>

												<div class="progress progress-mini">
													<div style="width:35%" class="progress-bar progress-bar-danger"></div>
												</div>
											</a>
										</li>

										<li>
											<a href="#">
												<div class="clearfix">
													<span class="pull-left">Unit Testing</span>
													<span class="pull-right">15%</span>
												</div>

												<div class="progress progress-mini">
													<div style="width:15%" class="progress-bar progress-bar-warning"></div>
												</div>
											</a>
										</li>

										<li>
											<a href="#">
												<div class="clearfix">
													<span class="pull-left">Bug Fixes</span>
													<span class="pull-right">90%</span>
												</div>

												<div class="progress progress-mini progress-striped active">
													<div style="width:90%" class="progress-bar progress-bar-success"></div>
												</div>
											</a>
										</li>
									</ul>
								</li>

								<li class="dropdown-footer">
									<a href="#">
										See tasks with details
										<i class="ace-icon fa fa-arrow-right"></i>
									</a>
								</li>
							</ul>
						</li>

						<li class="purple">
							<a data-toggle="dropdown" class="dropdown-toggle" href="#">
								<i class="ace-icon fa fa-bell icon-animated-bell"></i>
								<span class="badge badge-important">8</span>
							</a>

							<ul class="dropdown-menu-right dropdown-navbar navbar-pink dropdown-menu dropdown-caret dropdown-close">
								<li class="dropdown-header">
									<i class="ace-icon fa fa-exclamation-triangle"></i>
									8 Notifications
								</li>

								<li class="dropdown-content">
									<ul class="dropdown-menu dropdown-navbar navbar-pink">
										<li>
											<a href="#">
												<div class="clearfix">
													<span class="pull-left">
														<i class="btn btn-xs no-hover btn-pink fa fa-comment"></i>
														New Comments
													</span>
													<span class="pull-right badge badge-info">+12</span>
												</div>
											</a>
										</li>

										<li>
											<a href="#">
												<i class="btn btn-xs btn-primary fa fa-user"></i>
												Bob just signed up as an editor ...
											</a>
										</li>

										<li>
											<a href="#">
												<div class="clearfix">
													<span class="pull-left">
														<i class="btn btn-xs no-hover btn-success fa fa-shopping-cart"></i>
														New Orders
													</span>
													<span class="pull-right badge badge-success">+8</span>
												</div>
											</a>
										</li>

										<li>
											<a href="#">
												<div class="clearfix">
													<span class="pull-left">
														<i class="btn btn-xs no-hover btn-info fa fa-twitter"></i>
														Followers
													</span>
													<span class="pull-right badge badge-info">+11</span>
												</div>
											</a>
										</li>
									</ul>
								</li>

								<li class="dropdown-footer">
									<a href="#">
										See all notifications
										<i class="ace-icon fa fa-arrow-right"></i>
									</a>
								</li>
							</ul>
						</li>

						<li class="green">
							<a data-toggle="dropdown" class="dropdown-toggle" href="#">
								<i class="ace-icon fa fa-envelope icon-animated-vertical"></i>
								<span class="badge badge-success">5</span>
							</a>

							<ul class="dropdown-menu-right dropdown-navbar dropdown-menu dropdown-caret dropdown-close">
								<li class="dropdown-header">
									<i class="ace-icon fa fa-envelope-o"></i>
									5 Messages
								</li>

								<li class="dropdown-content">
									<ul class="dropdown-menu dropdown-navbar">
										<li>
											<a href="#" class="clearfix">
												<img src="assets/avatars/avatar.png" class="msg-photo" alt="Alex's Avatar" />
												<span class="msg-body">
													<span class="msg-title">
														<span class="blue">Alex:</span>
														Ciao sociis natoque penatibus et auctor ...
													</span>

													<span class="msg-time">
														<i class="ace-icon fa fa-clock-o"></i>
														<span>a moment ago</span>
													</span>
												</span>
											</a>
										</li>

										<li>
											<a href="#" class="clearfix">
												<img src="assets/avatars/avatar3.png" class="msg-photo" alt="Susan's Avatar" />
												<span class="msg-body">
													<span class="msg-title">
														<span class="blue">Susan:</span>
														Vestibulum id ligula porta felis euismod ...
													</span>

													<span class="msg-time">
														<i class="ace-icon fa fa-clock-o"></i>
														<span>20 minutes ago</span>
													</span>
												</span>
											</a>
										</li>

										<li>
											<a href="#" class="clearfix">
												<img src="assets/avatars/avatar4.png" class="msg-photo" alt="Bob's Avatar" />
												<span class="msg-body">
													<span class="msg-title">
														<span class="blue">Bob:</span>
														Nullam quis risus eget urna mollis ornare ...
													</span>

													<span class="msg-time">
														<i class="ace-icon fa fa-clock-o"></i>
														<span>3:15 pm</span>
													</span>
												</span>
											</a>
										</li>

										<li>
											<a href="#" class="clearfix">
												<img src="assets/avatars/avatar2.png" class="msg-photo" alt="Kate's Avatar" />
												<span class="msg-body">
													<span class="msg-title">
														<span class="blue">Kate:</span>
														Ciao sociis natoque eget urna mollis ornare ...
													</span>

													<span class="msg-time">
														<i class="ace-icon fa fa-clock-o"></i>
														<span>1:33 pm</span>
													</span>
												</span>
											</a>
										</li>

										<li>
											<a href="#" class="clearfix">
												<img src="assets/avatars/avatar5.png" class="msg-photo" alt="Fred's Avatar" />
												<span class="msg-body">
													<span class="msg-title">
														<span class="blue">Fred:</span>
														Vestibulum id penatibus et auctor  ...
													</span>

													<span class="msg-time">
														<i class="ace-icon fa fa-clock-o"></i>
														<span>10:09 am</span>
													</span>
												</span>
											</a>
										</li>
									</ul>
								</li>

								<li class="dropdown-footer">
									<a href="inbox.html">
										See all messages
										<i class="ace-icon fa fa-arrow-right"></i>
									</a>
								</li>
							</ul>
						</li>

						<li class="light-blue">
							<a data-toggle="dropdown" href="#" class="dropdown-toggle">
								<img class="nav-user-photo" src="assets/avatars/user.jpg" alt="<?php echo ucfirst($row["NAME"]);?>'s Photo" />
								<span class="user-info">
									<small>Welcome,</small>
									<?php echo ucfirst($row["NAME"]);?>
								</span>

								<i class="ace-icon fa fa-caret-down"></i>
							</a>

							<ul class="user-menu dropdown-menu-right dropdown-menu dropdown-yellow dropdown-caret dropdown-close">
								<li>
									<a href="#">
										<i class="ace-icon fa fa-cog"></i>
										Settings
									</a>
								</li>

								<li>
									<a href="profile.php">
										<i class="ace-icon fa fa-user"></i>
										Profile
									</a>
								</li>

								<li class="divider"></li>

								<li>
									<a href="logout.php">
										<i class="ace-icon fa fa-power-off"></i>
										Logout
									</a>
								</li>
							</ul>
						</li>
					</ul>
				</div>
			</div><!-- /.navbar-container -->
		</div>

		<div class="main-container" id="main-container">
			<script type="text/javascript">
				try{ace.settings.check('main-container' , 'fixed')}catch(e){}
			</script>

			<div id="sidebar" class="sidebar                  responsive">
				<script type="text/javascript">
					try{ace.settings.check('sidebar' , 'fixed')}catch(e){}
				</script>

				<div class="sidebar-shortcuts" id="sidebar-shortcuts">
					<div class="sidebar-shortcuts-large" id="sidebar-shortcuts-large">
						<button class="btn btn-success">
							<i class="ace-icon fa fa-signal"></i>
						</button>

						<button class="btn btn-info">
							<i class="ace-icon fa fa-pencil"></i>
						</button>

						<button class="btn btn-warning">
							<i class="ace-icon fa fa-users"></i>
						</button>

						<button class="btn btn-danger">
							<i class="ace-icon fa fa-cogs"></i>
						</button>
					</div>

					<div class="sidebar-shortcuts-mini" id="sidebar-shortcuts-mini">
						<span class="btn btn-success"></span>

						<span class="btn btn-info"></span>

						<span class="btn btn-warning"></span>

						<span class="btn btn-danger"></span>
					</div>
				</div><!-- /.sidebar-shortcuts -->

				<ul class="nav nav-list">
					<li class="">
						<a href="dashboard.php">
							<i class="menu-icon fa fa-tachometer"></i>
							<span class="menu-text"> Dashboard </span>
						</a>

						<b class="arrow"></b>
					</li>

					<li class="">
						<a href="#" class="dropdown-toggle">
							<i class="menu-icon fa fa-desktop"></i>
							<span class="menu-text">
								UI &amp; Elements
							</span>

							<b class="arrow fa fa-angle-down"></b>
						</a>

						<b class="arrow"></b>

						<ul class="submenu">
							<li class="">
								<a href="#" class="dropdown-toggle">
									<i class="menu-icon fa fa-caret-right"></i>

									Layouts
									<b class="arrow fa fa-angle-down"></b>
								</a>

								<b class="arrow"></b>

								<ul class="submenu">
									<li class="">
										<a href="top-menu.html">
											<i class="menu-icon fa fa-caret-right"></i>
											Top Menu
										</a>

										<b class="arrow"></b>
									</li>

									<li class="">
										<a href="two-menu-1.html">
											<i class="menu-icon fa fa-caret-right"></i>
											Two Menus 1
										</a>

										<b class="arrow"></b>
									</li>

									<li class="">
										<a href="two-menu-2.html">
											<i class="menu-icon fa fa-caret-right"></i>
											Two Menus 2
										</a>

										<b class="arrow"></b>
									</li>

									<li class="">
										<a href="mobile-menu-1.html">
											<i class="menu-icon fa fa-caret-right"></i>
											Default Mobile Menu
										</a>

										<b class="arrow"></b>
									</li>

									<li class="">
										<a href="mobile-menu-2.html">
											<i class="menu-icon fa fa-caret-right"></i>
											Mobile Menu 2
										</a>

										<b class="arrow"></b>
									</li>

									<li class="">
										<a href="mobile-menu-3.html">
											<i class="menu-icon fa fa-caret-right"></i>
											Mobile Menu 3
										</a>

										<b class="arrow"></b>
									</li>
								</ul>
							</li>

							<li class="">
								<a href="typography.html">
									<i class="menu-icon fa fa-caret-right"></i>
									Typography
								</a>

								<b class="arrow"></b>
							</li>

							<li class="">
								<a href="elements.html">
									<i class="menu-icon fa fa-caret-right"></i>
									Elements
								</a>

								<b class="arrow"></b>
							</li>

							<li class="">
								<a href="buttons.html">
									<i class="menu-icon fa fa-caret-right"></i>
									Buttons &amp; Icons
								</a>

								<b class="arrow"></b>
							</li>

							<li class="">
								<a href="content-slider.html">
									<i class="menu-icon fa fa-caret-right"></i>
									Content Sliders
								</a>

								<b class="arrow"></b>
							</li>

							<li class="">
								<a href="treeview.html">
									<i class="menu-icon fa fa-caret-right"></i>
									Treeview
								</a>

								<b class="arrow"></b>
							</li>

							<li class="">
								<a href="jquery-ui.html">
									<i class="menu-icon fa fa-caret-right"></i>
									jQuery UI
								</a>

								<b class="arrow"></b>
							</li>

							<li class="">
								<a href="nestable-list.html">
									<i class="menu-icon fa fa-caret-right"></i>
									Nestable Lists
								</a>

								<b class="arrow"></b>
							</li>

							<li class="">
								<a href="#" class="dropdown-toggle">
									<i class="menu-icon fa fa-caret-right"></i>

									Three Level Menu
									<b class="arrow fa fa-angle-down"></b>
								</a>

								<b class="arrow"></b>

								<ul class="submenu">
									<li class="">
										<a href="#">
											<i class="menu-icon fa fa-leaf green"></i>
											Item #1
										</a>

										<b class="arrow"></b>
									</li>

									<li class="">
										<a href="#" class="dropdown-toggle">
											<i class="menu-icon fa fa-pencil orange"></i>

											4th level
											<b class="arrow fa fa-angle-down"></b>
										</a>

										<b class="arrow"></b>

										<ul class="submenu">
											<li class="">
												<a href="#">
													<i class="menu-icon fa fa-plus purple"></i>
													Add Product
												</a>

												<b class="arrow"></b>
											</li>

											<li class="">
												<a href="#">
													<i class="menu-icon fa fa-eye pink"></i>
													View Products
												</a>

												<b class="arrow"></b>
											</li>
										</ul>
									</li>
								</ul>
							</li>
						</ul>
					</li>

					<li class="active open">
						<a href="#" class="dropdown-toggle">
							<i class="menu-icon fa fa-list"></i>
							<span class="menu-text">Tables</span>

							<b class="arrow fa fa-angle-down"></b>
						</a>

						<b class="arrow"></b>

						<ul class="submenu">
							<li class="">
								<a href="tables.html">
									<i class="menu-icon fa fa-caret-right"></i>
									Simple &amp; Dynamic
								</a>

								<b class="arrow"></b>
							</li>

							<li class="active">
								<a href="jqgrid.html">
									<i class="menu-icon fa fa-caret-right"></i>
									jqGrid plugin
								</a>

								<b class="arrow"></b>
							</li>
						</ul>
					</li>

					<li class="">
						<a href="#" class="dropdown-toggle">
							<i class="menu-icon fa fa-pencil-square-o"></i>
							<span class="menu-text"> Forms </span>

							<b class="arrow fa fa-angle-down"></b>
						</a>

						<b class="arrow"></b>

						<ul class="submenu">
							<li class="">
								<a href="form-elements.html">
									<i class="menu-icon fa fa-caret-right"></i>
									Form Elements
								</a>

								<b class="arrow"></b>
							</li>

							<li class="">
								<a href="form-elements-2.html">
									<i class="menu-icon fa fa-caret-right"></i>
									Form Elements 2
								</a>

								<b class="arrow"></b>
							</li>

							<li class="">
								<a href="form-wizard.html">
									<i class="menu-icon fa fa-caret-right"></i>
									Wizard &amp; Validation
								</a>

								<b class="arrow"></b>
							</li>

							<li class="">
								<a href="wysiwyg.html">
									<i class="menu-icon fa fa-caret-right"></i>
									Wysiwyg &amp; Markdown
								</a>

								<b class="arrow"></b>
							</li>

							<li class="">
								<a href="dropzone.html">
									<i class="menu-icon fa fa-caret-right"></i>
									Dropzone File Upload
								</a>

								<b class="arrow"></b>
							</li>
						</ul>
					</li>

					<li class="">
						<a href="widgets.html">
							<i class="menu-icon fa fa-list-alt"></i>
							<span class="menu-text"> Widgets </span>
						</a>

						<b class="arrow"></b>
					</li>

					<li class="">
						<a href="calendar.html">
							<i class="menu-icon fa fa-calendar"></i>

							<span class="menu-text">
								Calendar

								<span class="badge badge-transparent tooltip-error" title="2 Important Events">
									<i class="ace-icon fa fa-exclamation-triangle red bigger-130"></i>
								</span>
							</span>
						</a>

						<b class="arrow"></b>
					</li>

					<li class="">
						<a href="gallery.html">
							<i class="menu-icon fa fa-picture-o"></i>
							<span class="menu-text"> Gallery </span>
						</a>

						<b class="arrow"></b>
					</li>

					<li class="">
						<a href="#" class="dropdown-toggle">
							<i class="menu-icon fa fa-tag"></i>
							<span class="menu-text"> More Pages </span>

							<b class="arrow fa fa-angle-down"></b>
						</a>

						<b class="arrow"></b>

						<ul class="submenu">
							<li class="">
								<a href="profile.html">
									<i class="menu-icon fa fa-caret-right"></i>
									User Profile
								</a>

								<b class="arrow"></b>
							</li>

							<li class="">
								<a href="inbox.html">
									<i class="menu-icon fa fa-caret-right"></i>
									Inbox
								</a>

								<b class="arrow"></b>
							</li>

							<li class="">
								<a href="pricing.html">
									<i class="menu-icon fa fa-caret-right"></i>
									Pricing Tables
								</a>

								<b class="arrow"></b>
							</li>

							<li class="">
								<a href="invoice.html">
									<i class="menu-icon fa fa-caret-right"></i>
									Invoice
								</a>

								<b class="arrow"></b>
							</li>

							<li class="">
								<a href="timeline.html">
									<i class="menu-icon fa fa-caret-right"></i>
									Timeline
								</a>

								<b class="arrow"></b>
							</li>

							<li class="">
								<a href="email.html">
									<i class="menu-icon fa fa-caret-right"></i>
									Email Templates
								</a>

								<b class="arrow"></b>
							</li>

							<li class="">
								<a href="login.html">
									<i class="menu-icon fa fa-caret-right"></i>
									Login &amp; Register
								</a>

								<b class="arrow"></b>
							</li>
						</ul>
					</li>

					<li class="">
						<a href="#" class="dropdown-toggle">
							<i class="menu-icon fa fa-file-o"></i>

							<span class="menu-text">
								Other Pages

								<span class="badge badge-primary">5</span>
							</span>

							<b class="arrow fa fa-angle-down"></b>
						</a>

						<b class="arrow"></b>

						<ul class="submenu">
							<li class="">
								<a href="faq.html">
									<i class="menu-icon fa fa-caret-right"></i>
									FAQ
								</a>

								<b class="arrow"></b>
							</li>

							<li class="">
								<a href="error-404.html">
									<i class="menu-icon fa fa-caret-right"></i>
									Error 404
								</a>

								<b class="arrow"></b>
							</li>

							<li class="">
								<a href="error-500.html">
									<i class="menu-icon fa fa-caret-right"></i>
									Error 500
								</a>

								<b class="arrow"></b>
							</li>

							<li class="">
								<a href="grid.html">
									<i class="menu-icon fa fa-caret-right"></i>
									Grid
								</a>

								<b class="arrow"></b>
							</li>

							<li class="">
								<a href="blank.html">
									<i class="menu-icon fa fa-caret-right"></i>
									Blank Page
								</a>

								<b class="arrow"></b>
							</li>
						</ul>
					</li>
				</ul><!-- /.nav-list -->

				<div class="sidebar-toggle sidebar-collapse" id="sidebar-collapse">
					<i class="ace-icon fa fa-angle-double-left" data-icon1="ace-icon fa fa-angle-double-left" data-icon2="ace-icon fa fa-angle-double-right"></i>
				</div>

				<script type="text/javascript">
					try{ace.settings.check('sidebar' , 'collapsed')}catch(e){}
				</script>
			</div>

			<div class="main-content">
				<div class="main-content-inner">
					<div class="breadcrumbs" id="breadcrumbs">
						<script type="text/javascript">
							try{ace.settings.check('breadcrumbs' , 'fixed')}catch(e){}
						</script>

						<ul class="breadcrumb">
							<li>
								<i class="ace-icon fa fa-home home-icon"></i>
								<a href="#">Dashboard</a>
							</li>

							<li>
								<a href="#">Merchant</a>
							</li>
							<li class="active">Transaction Record</li>
						</ul><!-- /.breadcrumb -->

						<div class="nav-search" id="nav-search">
							<form class="form-search">
								<span class="input-icon">
									<input type="text" placeholder="Search ..." class="nav-search-input" id="nav-search-input" autocomplete="off" />
									<i class="ace-icon fa fa-search nav-search-icon"></i>
								</span>
							</form>
						</div><!-- /.nav-search -->
					</div>

					<div class="page-content">
						<div class="ace-settings-container" id="ace-settings-container">
							<div class="btn btn-app btn-xs btn-warning ace-settings-btn" id="ace-settings-btn">
								<i class="ace-icon fa fa-cog bigger-130"></i>
							</div>

							<div class="ace-settings-box clearfix" id="ace-settings-box">
								<div class="pull-left width-50">
									<div class="ace-settings-item">
										<div class="pull-left">
											<select id="skin-colorpicker" class="hide">
												<option data-skin="no-skin" value="#438EB9">#438EB9</option>
												<option data-skin="skin-1" value="#222A2D">#222A2D</option>
												<option data-skin="skin-2" value="#C6487E">#C6487E</option>
												<option data-skin="skin-3" value="#D0D0D0">#D0D0D0</option>
											</select>
										</div>
										<span>&nbsp; Choose Skin</span>
									</div>

									<div class="ace-settings-item">
										<input type="checkbox" class="ace ace-checkbox-2" id="ace-settings-navbar" />
										<label class="lbl" for="ace-settings-navbar"> Fixed Navbar</label>
									</div>

									<div class="ace-settings-item">
										<input type="checkbox" class="ace ace-checkbox-2" id="ace-settings-sidebar" />
										<label class="lbl" for="ace-settings-sidebar"> Fixed Sidebar</label>
									</div>

									<div class="ace-settings-item">
										<input type="checkbox" class="ace ace-checkbox-2" id="ace-settings-breadcrumbs" />
										<label class="lbl" for="ace-settings-breadcrumbs"> Fixed Breadcrumbs</label>
									</div>

									<div class="ace-settings-item">
										<input type="checkbox" class="ace ace-checkbox-2" id="ace-settings-rtl" />
										<label class="lbl" for="ace-settings-rtl"> Right To Left (rtl)</label>
									</div>

									<div class="ace-settings-item">
										<input type="checkbox" class="ace ace-checkbox-2" id="ace-settings-add-container" />
										<label class="lbl" for="ace-settings-add-container">
											Inside
											<b>.container</b>
										</label>
									</div>
								</div><!-- /.pull-left -->

								<div class="pull-left width-50">
									<div class="ace-settings-item">
										<input type="checkbox" class="ace ace-checkbox-2" id="ace-settings-hover" />
										<label class="lbl" for="ace-settings-hover"> Submenu on Hover</label>
									</div>

									<div class="ace-settings-item">
										<input type="checkbox" class="ace ace-checkbox-2" id="ace-settings-compact" />
										<label class="lbl" for="ace-settings-compact"> Compact Sidebar</label>
									</div>

									<div class="ace-settings-item">
										<input type="checkbox" class="ace ace-checkbox-2" id="ace-settings-highlight" />
										<label class="lbl" for="ace-settings-highlight"> Alt. Active Item</label>
									</div>
								</div><!-- /.pull-left -->
							</div><!-- /.ace-settings-box -->
						</div><!-- /.ace-settings-container -->

						

					<div class="row">
					<div class="col-xs-4" align="center">
						<table class="table">
							<tr><td colspan="2">Collections</td></tr>
                <?php 
                $sql7sum="Select SUM(INVOICE_VALUE) as INVOICE_VALUE FROM ncl_invoices where DATETIME > DATE_SUB(CURDATE(), INTERVAL 7 DAY) 
                AND MERCHANT_ID=$_SESSION[ID]";
                //echo $sqlsum;
                $data7=mysql_fetch_array(mysql_query($sql7sum));
                ?>
              <tr>
								<td class="tableheader">Last 7 days</td>
								<td class="tablerow2"><?php echo $data7['INVOICE_VALUE'];?></td>
							</tr>
              <?php 
                $sql15sum="Select SUM(INVOICE_VALUE) as INVOICE_VALUE FROM ncl_invoices where DATETIME > DATE_SUB(CURDATE(), INTERVAL 15 DAY) 
                AND MERCHANT_ID=$_SESSION[ID]";
                //echo $sqlsum;
                $data15=mysql_fetch_array(mysql_query($sql15sum));
                ?>
              <tr>
                <td class="tableheader">Last 15 days</td>
                <td class="tablerow2"><?php echo $data15['INVOICE_VALUE'];?></td>
              </tr>
              <?php 
                $sql30sum="Select SUM(INVOICE_VALUE) as INVOICE_VALUE FROM ncl_invoices where DATETIME > DATE_SUB(CURDATE(), INTERVAL 30 DAY) 
                AND MERCHANT_ID=$_SESSION[ID]";
                //echo $sqlsum;
                $data30=mysql_fetch_array(mysql_query($sql30sum));
                ?>
              <tr>
                <td class="tableheader">Last 30 days</td>
                <td class="tablerow2"><?php echo $data30['INVOICE_VALUE'];?></td>
              </tr>
						</table>
					</div>
					<?php
					if($_SESSION["ID"]) {
					?>

					<form action="dashboard.php" method="post">
						<div class="row">
							<div class="col-xs-12" align="center">
                <div class="page-header">
                  <h1 align="center">
                    Transaction Record
                    <small>
                      <i class="ace-icon fa fa-angle-double-right"></i>
                    </small>
                  </h1>
                </div><!-- /.page-header -->
								<button type="submit" name="today" id="today" value="Today" class="btn btn-primary">Today</button>&nbsp;
								<button type="submit" name="yesterday" id="yesterday" value="Yesterday" class="btn btn-primary">Yesterday</button>&nbsp;
								<button type="submit" name="Last7Days" id="Last7Days" value="Last 7 Days" class="btn btn-primary">Last 7 Days</button>&nbsp;
								<button type="submit" name="Last15Days" id="Last15Days" value="Last 15 Days" class="btn btn-primary">Last 15 Days</button>&nbsp;
								<button type="submit" name="Last30Days" id="Last30Days" value="Last 30 Days" class="btn btn-primary">Last 30 Days</button>&nbsp;
								<button type="submit" name="Last6Months" id="Last6Months" value="Last 6 Months" class="btn btn-primary">Last 6 Months</button>&nbsp;
								<button type="submit" name="Last1Year" id="Last1Year" value="Last 1 Year" class="btn btn-primary">Last 1 Year</button>&nbsp;
								<button type="submit" name="Last5Years" id="Last5Years" value="Last 5 Years" class="btn btn-primary">Last 5 Years</button>&nbsp;
							</div>
							<div class="row">
								<div class="col-xs-12" align="center" height="10px">&nbsp;</div>
							</div>
							<div class="col-xs-12">
								<div class="col-xs-2"></div>
                <div class="col-xs-2" align="center">From Date:
									<div class="form-group">
		                <div class='input-group date' id='fromdate'>
		                  <input name="from" id="from" type="text" class="tcal" align="center" /><!--   // class="form-control" />-->
		                    <!--<span class="input-group-addon">
		                        <span class="glyphicon glyphicon-calendar"></span>
		                    </span>-->
		                </div>
		              </div>
						    </div>					
								<div class="col-xs-2" align="center">To Date:
									<div class="form-group">
		                <div class='input-group date' id='todate'>
		                  <input name="to" id="to" type="text" class="tcal" align="center" /><!--   // class="form-control" />-->
		                    <!--<span class="input-group-addon">
		                        <span class="glyphicon glyphicon-calendar"></span>
		                    </span>-->
		                </div>
						      </div>
								</div>
								<div class="col-xs-2" align="center">
									<button class="btn btn-success" name="Search" id="Search" type="submit" value="Search" onclick="Search()">Search</button>
								</div>				
							</div>
						</div>
            <div class="hr hr-12 hr-double"></div>
							<div class="row">
							<div class="col-xs-12">
								<!-- PAGE CONTENT BEGINS -->
								<!--<div class="alert alert-info">
									<button class="close" data-dismiss="alert">
										<i class="ace-icon fa fa-times"></i>
									</button>

									<i class="ace-icon fa fa-hand-o-right"></i>
									Please note that demo server is not configured to save the changes, therefore you may see an error message.
								</div>-->
                  <!--
                  From Date : <input type="text" id="fromdate" name="fromdate">
                  To Date : <input type="text" id="todate" name="todate">-->
                  <?php
                  //if (!isset($_POST['submit']))
                  //{
                  //$sqlsum="Select ncl_transactions.TIMESTAMP FROM `ncl_transactions`, SUM(`ncl_invoices`.INVOICE_VALUE) from ncl_invoices LEFT JOIN  `ncl_invoices` ON ncl_transactions.INVOICE_ID = ncl_invoices.ID 
                  //where ncl_transactions.TIMESTAMP > DATE_SUB(CURDATE(), INTERVAL 7 DAY) AND MERCHANT_ID=$_SESSION[ID]";
                  /*echo "$sqlsum"; 
                  $resultsum=mysql_query($sqlsum);
                  $numsum=mysql_num_rows($resultsum);
                  $numsumr=mysql_fetch_array($numsum);
                  echo "<br>".$resultsum;
                  echo "<br>".$numsumr['INVOICE_VALUE'];*/
                  /* Left Join 
                  $sql="Select ncl_transactions.TYPE,ncl_transactions.NCL_CARD_ID, ncl_transactions.TIMESTAMP, ncl_transactions.CONSUMER_ID, 
                  ncl_transactions.MERCHANT_ID, ncl_transactions.STATUS, ncl_transactions.NCL_POS_ID, ncl_invoices.INVOICE_VALUE
                  FROM  `ncl_transactions` LEFT JOIN  `ncl_invoices` ON ncl_transactions.INVOICE_ID = ncl_invoices.ID";
                  */
                  $sql="Select ncl_transactions.TYPE,ncl_transactions.NCL_CARD_ID, ncl_transactions.TIMESTAMP, ncl_transactions.CONSUMER_ID, 
                  ncl_transactions.MERCHANT_ID, ncl_transactions.STATUS, ncl_transactions.NCL_POS_ID, ncl_invoices.INVOICE_VALUE
                  FROM  `ncl_transactions` LEFT JOIN  `ncl_invoices` ON ncl_transactions.INVOICE_ID = ncl_invoices.ID 
                  where ncl_transactions.TIMESTAMP > DATE_SUB(CURDATE(), INTERVAL 1 DAY) AND ncl_transactions.MERCHANT_ID=$_SESSION[ID]";

                    if($_POST['today'] == 'Today')
                    {
                      ///do today's processing
                      $today = date('Y-m-d',time());
                      //echo $today;
                      $sql="Select ncl_transactions.TYPE,ncl_transactions.NCL_CARD_ID, ncl_transactions.TIMESTAMP, ncl_transactions.CONSUMER_ID, 
                  ncl_transactions.MERCHANT_ID, ncl_transactions.STATUS, ncl_transactions.NCL_POS_ID, ncl_invoices.INVOICE_VALUE
                  FROM  `ncl_transactions` LEFT JOIN  `ncl_invoices` ON ncl_transactions.INVOICE_ID = ncl_invoices.ID where 
                  ncl_transactions.TIMESTAMP='$today' AND ncl_transactions.MERCHANT_ID=$_SESSION[ID]";
                  //order by ID desc";
                      //$sql="select * from ncl_transactions where TIMESTAMP='$today' AND MERCHANT_ID=$_SESSION[ID] order by ID desc";
                    }
                    elseif($_POST['yesterday'] == 'Yesterday')
                    {
                      ///do yesterday's processing
                      $m= date("m"); // Month value
                      $de= date("d"); //today's date
                      $y= date("Y"); // Year value
                      $yesterday= date('Y-m-d', mktime(0,0,0,$m,($de-1),$y)); 
                      //echo $yesterday;
                      $sql="Select ncl_transactions.TYPE,ncl_transactions.NCL_CARD_ID, ncl_transactions.TIMESTAMP, ncl_transactions.CONSUMER_ID, 
                  ncl_transactions.MERCHANT_ID, ncl_transactions.STATUS, ncl_transactions.NCL_POS_ID, ncl_invoices.INVOICE_VALUE
                  FROM  `ncl_transactions` LEFT JOIN  `ncl_invoices` ON ncl_transactions.INVOICE_ID = ncl_invoices.ID 
                  where ncl_transactions.TIMESTAMP='$yesterday' AND ncl_transactions.MERCHANT_ID=$_SESSION[ID]";
                      //for($i=0; $i<=15; $i++){
                      //echo date('Y-m-d',strtotime("$i day"))."<br>";
                      //}
                    }
                    elseif($_POST['Last7Days'] == 'Last 7 Days')
                    {
                      ///do yesterday's processing
                      $m= date("m"); // Month value
                      $de= date("d"); //today's date
                      $y= date("Y"); // Year value
                      //$yesterday= date('Y-m-d', mktime(0,0,0,$m,($de-1),$y)); 
                      //echo $yesterday;
                      //$sql="select * from ncl_transactions where TIMESTAMP='$yesterday' AND MERCHANT_ID=$_SESSION[ID] order by ID desc";
                      //for($i=0; $i<=7; $i++)
                      //{
                        //echo date('Y-m-d',strtotime("$i day"))."<br>";
                        $sql="Select ncl_transactions.TYPE,ncl_transactions.NCL_CARD_ID, ncl_transactions.TIMESTAMP, ncl_transactions.CONSUMER_ID, 
                  ncl_transactions.MERCHANT_ID, ncl_transactions.STATUS, ncl_transactions.NCL_POS_ID, ncl_invoices.INVOICE_VALUE
                  FROM  `ncl_transactions` LEFT JOIN  `ncl_invoices` ON ncl_transactions.INVOICE_ID = ncl_invoices.ID where 
                  ncl_transactions.TIMESTAMP>= DATE_SUB(CURDATE(), INTERVAL 7 DAY) AND ncl_transactions.MERCHANT_ID=$_SESSION[ID]";


                        //$sql="select * from ncl_transactions where TIMESTAMP>= DATE_SUB(CURDATE(), INTERVAL 7 DAY) AND MERCHANT_ID=$_SESSION[ID] order by ID desc";
                      //}
                    }
                    elseif($_POST['Last15Days'] == 'Last 15 Days')
                    {
                      ///do yesterday's processing
                      $m= date("m"); // Month value
                      $de= date("d"); //today's date
                      $y= date("Y"); // Year value
                      //$yesterday= date('Y-m-d', mktime(0,0,0,$m,($de-1),$y)); 
                      //echo $yesterday;
                      //$sql="select * from ncl_transactions where TIMESTAMP='$yesterday' AND MERCHANT_ID=$_SESSION[ID] order by ID desc";
                      //for($i=0; $i<=15; $i++)
                      //{
                        //echo date('Y-m-d',strtotime("$i day"))."<br>";
                        $sql="Select ncl_transactions.TYPE,ncl_transactions.NCL_CARD_ID, ncl_transactions.TIMESTAMP, ncl_transactions.CONSUMER_ID, 
                  ncl_transactions.MERCHANT_ID, ncl_transactions.STATUS, ncl_transactions.NCL_POS_ID, ncl_invoices.INVOICE_VALUE
                  FROM  `ncl_transactions` LEFT JOIN  `ncl_invoices` ON ncl_transactions.INVOICE_ID = ncl_invoices.ID where 
                  ncl_transactions.TIMESTAMP>= DATE_SUB(CURDATE(), INTERVAL 15 DAY) AND ncl_transactions.MERCHANT_ID=$_SESSION[ID]";
                        //$sql="select * from ncl_transactions where TIMESTAMP>= DATE_SUB(CURDATE(), INTERVAL 15 DAY) AND MERCHANT_ID=$_SESSION[ID] order by ID desc";
                      //}
                    }
                    elseif($_POST['Last30Days'] == 'Last 30 Days')
                    {
                      ///do yesterday's processing
                      $m= date("m"); // Month value
                      $de= date("d"); //today's date
                      $y= date("Y"); // Year value
                      //$yesterday= date('Y-m-d', mktime(0,0,0,$m,($de-1),$y)); 
                      //echo $yesterday;
                      //$sql="select * from ncl_transactions where TIMESTAMP='$yesterday' AND MERCHANT_ID=$_SESSION[ID] order by ID desc";
                      //for($i=0; $i<=30; $i++)
                      //{
                        //echo date('Y-m-d',strtotime("$i day"))."<br>";
                        $sql="Select ncl_transactions.TYPE,ncl_transactions.NCL_CARD_ID, ncl_transactions.TIMESTAMP, ncl_transactions.CONSUMER_ID, 
                  ncl_transactions.MERCHANT_ID, ncl_transactions.STATUS, ncl_transactions.NCL_POS_ID, ncl_invoices.INVOICE_VALUE
                  FROM  `ncl_transactions` LEFT JOIN  `ncl_invoices` ON ncl_transactions.INVOICE_ID = ncl_invoices.ID where 
                  ncl_transactions.TIMESTAMP>= DATE_SUB(CURDATE(), INTERVAL 30 DAY) AND ncl_transactions.MERCHANT_ID=$_SESSION[ID]";
                        //$sql="select * from ncl_transactions where TIMESTAMP>= DATE_SUB(CURDATE(), INTERVAL 30 DAY) AND MERCHANT_ID=$_SESSION[ID] order by ID desc";
                      //}
                    }
                    elseif($_POST['Last6Months'] == 'Last 6 Months')
                    {
                      ///do yesterday's processing
                      $m= date("m"); // Month value
                      $de= date("d"); //today's date
                      $y= date("Y"); // Year value
                      //$yesterday= date('Y-m-d', mktime(0,0,0,$m,($de-1),$y)); 
                      //echo $yesterday;
                      //$sql="select * from ncl_transactions where TIMESTAMP='$yesterday' AND MERCHANT_ID=$_SESSION[ID] order by ID desc";
                      //for($i=0; $i<=180; $i++)
                      //{
                        //echo date('Y-m-d',strtotime("$i day"))."<br>";
                        $sql="Select ncl_transactions.TYPE,ncl_transactions.NCL_CARD_ID, ncl_transactions.TIMESTAMP, ncl_transactions.CONSUMER_ID, 
                  ncl_transactions.MERCHANT_ID, ncl_transactions.STATUS, ncl_transactions.NCL_POS_ID, ncl_invoices.INVOICE_VALUE
                  FROM  `ncl_transactions` LEFT JOIN  `ncl_invoices` ON ncl_transactions.INVOICE_ID = ncl_invoices.ID where 
                  ncl_transactions.TIMESTAMP>= DATE_SUB(CURDATE(), INTERVAL 6 MONTH) AND ncl_transactions.MERCHANT_ID=$_SESSION[ID]";
                        //$sql="select * from ncl_transactions where TIMESTAMP>= DATE_SUB(CURDATE(), INTERVAL 6 MONTH) AND MERCHANT_ID=$_SESSION[ID] order by ID desc";
                      //}
                    }
                    elseif($_POST['Last1Year'] == 'Last 1 Year')
                    {
                      ///do yesterday's processing
                      $m= date("m"); // Month value
                      $de= date("d"); //today's date
                      $y= date("Y"); // Year value
                      //$yesterday= date('Y-m-d', mktime(0,0,0,$m,($de-1),$y)); 
                      //echo $yesterday;
                      //$sql="select * from ncl_transactions where TIMESTAMP='$yesterday' AND MERCHANT_ID=$_SESSION[ID] order by ID desc";
                      //for($i=0; $i<=180; $i++)
                      //{
                        //echo date('Y-m-d',strtotime("$i day"))."<br>";
                        $sql="Select ncl_transactions.TYPE,ncl_transactions.NCL_CARD_ID, ncl_transactions.TIMESTAMP, ncl_transactions.CONSUMER_ID, 
                  ncl_transactions.MERCHANT_ID, ncl_transactions.STATUS, ncl_transactions.NCL_POS_ID, ncl_invoices.INVOICE_VALUE
                  FROM  `ncl_transactions` LEFT JOIN  `ncl_invoices` ON ncl_transactions.INVOICE_ID = ncl_invoices.ID where 
                  ncl_transactions.TIMESTAMP>= DATE_SUB(CURDATE(), INTERVAL 1 YEAR) AND ncl_transactions.MERCHANT_ID=$_SESSION[ID]";
                        //$sql="select * from ncl_transactions where TIMESTAMP>= DATE_SUB(CURDATE(), INTERVAL 1 YEAR) AND MERCHANT_ID=$_SESSION[ID] order by ID desc";
                      //}
                    }
                    elseif($_POST['Last5Years'] == 'Last 5 Years')
                    {
                      ///do yesterday's processing
                      $m= date("m"); // Month value
                      $de= date("d"); //today's date
                      $y= date("Y"); // Year value
                      //$yesterday= date('Y-m-d', mktime(0,0,0,$m,($de-1),$y)); 
                      //echo $yesterday;
                      //$sql="select * from ncl_transactions where TIMESTAMP='$yesterday' AND MERCHANT_ID=$_SESSION[ID] order by ID desc";
                      //for($i=0; $i<=180; $i++)
                      //{
                        //echo date('Y-m-d',strtotime("$i day"))."<br>";
                        $sql="Select ncl_transactions.TYPE,ncl_transactions.NCL_CARD_ID, ncl_transactions.TIMESTAMP, ncl_transactions.CONSUMER_ID, 
                  ncl_transactions.MERCHANT_ID, ncl_transactions.STATUS, ncl_transactions.NCL_POS_ID, ncl_invoices.INVOICE_VALUE
                  FROM  `ncl_transactions` LEFT JOIN  `ncl_invoices` ON ncl_transactions.INVOICE_ID = ncl_invoices.ID where 
                  ncl_transactions.TIMESTAMP>= DATE_SUB(CURDATE(), INTERVAL 5 YEAR) AND ncl_transactions.MERCHANT_ID=$_SESSION[ID]";
                        //$sql="select * from ncl_transactions where TIMESTAMP>= DATE_SUB(CURDATE(), INTERVAL 5 YEAR) AND MERCHANT_ID=$_SESSION[ID] order by ID desc";
                      //}
                    }
                    elseif($_POST['Search'] == 'Search')
                    {
                      /*Date Range*/
                      $fromdate=$_POST['from'];
                      $todate=$_POST['to'];
                      //echo "$fromdate"."&nbsp;"."$todate";
                      //$sql="select * from ncl_transactions where MERCHANT_ID=$_SESSION[ID] order by ID desc";
                      if($fromdate!='' && $todate!='')
                      {
                        $sql="Select ncl_transactions.TYPE,ncl_transactions.NCL_CARD_ID, ncl_transactions.TIMESTAMP, ncl_transactions.CONSUMER_ID, 
                  ncl_transactions.MERCHANT_ID, ncl_transactions.STATUS, ncl_transactions.NCL_POS_ID, ncl_invoices.INVOICE_VALUE
                  FROM  `ncl_transactions` LEFT JOIN  `ncl_invoices` ON ncl_transactions.INVOICE_ID = ncl_invoices.ID where 
                  ncl_transactions.TIMESTAMP BETWEEN '$fromdate' AND '$todate' AND ncl_transactions.MERCHANT_ID=$_SESSION[ID]";
                        //$sql="select * from ncl_transactions where TIMESTAMP BETWEEN '$fromdate' AND '$todate' AND MERCHANT_ID=$_SESSION[ID] order by ID desc";
                      }
                      else
                      {
                        echo "<br>"."Please Choose Both From & To Dates!!!!";
                      }  
                    }



                  //$sql="select * from ncl_transactions where TIMESTAMP>= DATE_SUB(NOW(), INTERVAL 1 DAY) AND MERCHANT_ID=$_SESSION[ID] order by ID desc";       
                  //$sql="select * from ncl_transactions where TIMESTAMP>= DATE_SUB(NOW(), INTERVAL 2 DAY) AND MERCHANT_ID=$_SESSION[ID] order by ID desc";       
                  //$sql="select * from ncl_transactions where TIMESTAMP>= DATE_SUB(NOW(), INTERVAL 1 WEEK) AND MERCHANT_ID=$_SESSION[ID] order by ID desc";
                  //$sql="select * from ncl_transactions where TIMESTAMP>= DATE_SUB(NOW(), INTERVAL 1 MONTH) AND MERCHANT_ID=$_SESSION[ID] order by ID desc";
                  //$sql="select * from ncl_transactions where TIMESTAMP>= DATE_SUB(NOW(), INTERVAL 6 MONTH) AND MERCHANT_ID=$_SESSION[ID] order by ID desc";
                  //$sql="select * from ncl_transactions where TIMESTAMP>= DATE_SUB(NOW(), INTERVAL 10 YEAR) AND MERCHANT_ID=$_SESSION[ID] order by ID desc";
                  //$sql="select * from ncl_transactions where TIMESTAMP>= DATE_SUB(CURDATE(), INTERVAL 7 DAY) AND MERCHANT_ID=$_SESSION[ID] order by ID desc";
                  //$sql="select * from ncl_transactions where TIMESTAMP='$yesterday' AND MERCHANT_ID=$_SESSION[ID] order by ID desc";
                  //echo "<br>"."$sql";
                  $result=mysql_query($sql);
                  $num=mysql_num_rows($result);//if (mysql_num_rows($result) > 0) {
                  //echo "<br>"."$result";
                  //echo "<br>"."Number Of Rows:"."$num";

                  //INSERT INTO `dev_payting`.`ncl_transactions` (`ID`, `TYPE`, `INVOICE_ID`, `NCL_CARD_ID`, `TIMESTAMP`, `CONSUMER_ID`, `MERCHANT_ID`, `STATUS`, `NCL_POS_ID`) VALUES ('2', '2', '2', '2', '2', '2', '2', '1', '2');
                  ?>
                  <tr class="table">
                  <td align="center">
                  <?php 
                        if($num==0)
                        {
                          echo "<br>"."No Record Found!";
                        }
                        else
                        {
                          //echo strtoupper("Transaction Record");
                  ?>
                  <table class="table" cellpadding="10" cellspacing="1" width="100%" height="100%" align="center" id="printTable" >
                  <tr class="tableheader">


                  <th>Sl No</th>
                  <th>INVOICE VALUE</th>
                  <th>TYPE</th>
                  <th>NCL CARD ID</th>
                  <th>TIMESTAMP</th>
                  <th>CONSUMER ID</th>
                  <th>MERCHANT ID</th>
                  <th>STATUS</th>
                  <th>NCL POS ID</th>
                  </tr>
                  <?php 
                  $i=0;

                  while($row=mysql_fetch_array($result)){
                  //while ($i < $row) {
                  //while ($row=mysql_fetch_array($result)) {
                  //while($row)// = mysql_fetch_assoc($result))
                  //
                    //if($row[]!=0){
                   // for($1=1;$i<$num;$i++){
                  	?>
                  <tr class="tablerow2">
                  <?php ?>
                  	<td><?php echo ++$i;//$row[0];?></td>
                    <td><?php echo $row['INVOICE_VALUE'];?></td>
                  	<td><?php echo $row['TYPE'];?></td>
                  	<td><?php echo $row['NCL_CARD_ID'];?></td>
                    <td><?php echo $row['TIMESTAMP'];?></td>
                    <td><?php echo $row['CONSUMER_ID'];?></td>
                    <td><?php echo $row['MERCHANT_ID'];?></td>
                    <td><?php echo $row['STATUS'];?></td>
                    <td><?php echo $row['NCL_POS_ID'];?></td>
                  </tr>
                  <?php
                  //}
                  //else{
                    //echo "No Record Found!";
                  //}
                  //$i++;
                  }
                  }
                  //}



                  }

                  ?>
                  </table>
                  <!--<button onclick="()">Print</button>-->
                  </td>
                  </tr>
                  </td>
                  </tr>
                  </table>
                  <!--<div id="jqxgrid"></div>-->

								<script type="text/javascript">
								$(document).ready(function () {
								    // prepare the data
								    var source ={
								        datatype: "json",
								        datafields: [{ name: 'INVOICE_VALUE' },{ name: 'TYPE' },{ name: 'NCL_CARD_ID' },{ name: 'TIMESTAMP' },{ name: 'CONSUMER_ID' },{ name: 'MERCHANT_ID' },{ name: ' ' },{ name: 'NCL_POS_ID' },],
								        url: 'data.php'
								    };
								    $("#jqxgrid").jqxGrid({
								        source: source,
								        theme: 'classic',
								        columns: [{ text: 'INVOICE_VALUE', datafield: 'INVOICE_VALUE', width: 250 },{ text: 'TYPE', datafield: 'TYPE', width: 150 },{ text: 'NCL_CARD_ID', datafield: 'NCL_CARD_ID', width: 180 },{ text: 'TIMESTAMP', datafield: 'TIMESTAMP', width: 200 },{ text: 'CONSUMER_ID', datafield: 'CONSUMER_ID', width: 120 },{ text: 'MERCHANT_ID', datafield: 'MERCHANT_ID', width: 150 },{ text: 'STATUS', datafield: 'STATUS', width: 150 },{ text: 'NCL_POS_ID', datafield: 'NCL_POS_ID', width: 150 }]
								    });
								});
								</script>
								<table id="grid-table"></table>

								<div id="grid-pager"></div>

								<script type="text/javascript">
									var $path_base = ".";//in Ace demo this will be used for editurl parameter
								</script>
                <div class="hr hr-12 hr-double"></div>

              <div class="row">
              <div class="col-xs-12" align="center">
                <!-- PAGE CONTENT BEGINS -->
                  <input class="btn btn-danger" align="center" type=button onClick="location.href='http://192.168.1.28/ace-master/osTicket-v1.9.12/upload/'" value='Open Ticket'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  <input class="btn btn-danger" align="center" type=button onClick="location.href='http://192.168.1.28/ace-master/osTicket-v1.9.12/upload/'" value='View Ticket'>


                <!-- PAGE CONTENT ENDS -->
              </div><!-- /.col -->
            </div><!-- /.row -->
          </div><!-- /.page-content -->
        </div>
      </div><!-- /.main-content -->
			<div class="footer">
				<div class="footer-inner">
					<div class="footer-content">
						<span class="bigger-120">
							<span class="blue bolder">Merchant</span>
							Application &copy; 2016
						</span>

						&nbsp; &nbsp;
						<span class="action-buttons">
							<a href="#">
								<i class="ace-icon fa fa-twitter-square light-blue bigger-150"></i>
							</a>

							<a href="#">
								<i class="ace-icon fa fa-facebook-square text-primary bigger-150"></i>
							</a>

							<a href="#">
								<i class="ace-icon fa fa-rss-square orange bigger-150"></i>
							</a>
						</span>
					</div>
				</div>
			</div>

			<a href="#" id="btn-scroll-up" class="btn-scroll-up btn btn-sm btn-inverse">
				<i class="ace-icon fa fa-angle-double-up icon-only bigger-110"></i>
			</a>
		</div><!-- /.main-container -->

		<!-- basic scripts -->

		<!--[if !IE]> -->
		<script src="assets/js/jquery.2.1.1.min.js"></script>

		<!-- <![endif]-->

		<!--[if IE]>
<script src="assets/js/jquery.1.11.1.min.js"></script>
<![endif]-->

		<!--[if !IE]> -->
		<script type="text/javascript">
			window.jQuery || document.write("<script src='assets/js/jquery.min.js'>"+"<"+"/script>");
		</script>

		<!-- <![endif]-->

		<!--[if IE]>
<script type="text/javascript">
 window.jQuery || document.write("<script src='assets/js/jquery1x.min.js'>"+"<"+"/script>");
</script>
<![endif]-->
		<script type="text/javascript">
			if('ontouchstart' in document.documentElement) document.write("<script src='assets/js/jquery.mobile.custom.min.js'>"+"<"+"/script>");
		</script>
		<script src="assets/js/bootstrap.min.js"></script>

		<!-- page specific plugin scripts -->
		<script src="assets/js/moment.min.js"></script>
		<script src="assets/js/bootstrap-datepicker.js"></script>
		<script src="assets/js/bootstrap-datepicker.min.js"></script>
		<script src="assets/js/jquery.jqGrid.min.js"></script>
		<script src="assets/js/grid.locale-en.js"></script>

		<!-- ace scripts -->
		<script src="assets/js/ace-elements.min.js"></script>
		<script src="assets/js/ace.min.js"></script>

		<!-- inline scripts related to this page -->
		<!--<script type="text/javascript">
			var grid_data = 
			[ 
				{id:"1",name:"Desktop Computer",note:"note",stock:"Yes",ship:"FedEx", sdate:"2007-12-03"},
				{id:"2",name:"Laptop",note:"Long text ",stock:"Yes",ship:"InTime",sdate:"2007-12-03"},
				{id:"3",name:"LCD Monitor",note:"note3",stock:"Yes",ship:"TNT",sdate:"2007-12-03"},
				{id:"4",name:"Speakers",note:"note",stock:"No",ship:"ARAMEX",sdate:"2007-12-03"},
				{id:"5",name:"Laser Printer",note:"note2",stock:"Yes",ship:"FedEx",sdate:"2007-12-03"},
				{id:"6",name:"Play Station",note:"note3",stock:"No", ship:"FedEx",sdate:"2007-12-03"},
				{id:"7",name:"Mobile Telephone",note:"note",stock:"Yes",ship:"ARAMEX",sdate:"2007-12-03"},
				{id:"8",name:"Server",note:"note2",stock:"Yes",ship:"TNT",sdate:"2007-12-03"},
				{id:"9",name:"Matrix Printer",note:"note3",stock:"No", ship:"FedEx",sdate:"2007-12-03"},
				{id:"10",name:"Desktop Computer",note:"note",stock:"Yes",ship:"FedEx", sdate:"2007-12-03"},
				{id:"11",name:"Laptop",note:"Long text ",stock:"Yes",ship:"InTime",sdate:"2007-12-03"},
				{id:"12",name:"LCD Monitor",note:"note3",stock:"Yes",ship:"TNT",sdate:"2007-12-03"},
				{id:"13",name:"Speakers",note:"note",stock:"No",ship:"ARAMEX",sdate:"2007-12-03"},
				{id:"14",name:"Laser Printer",note:"note2",stock:"Yes",ship:"FedEx",sdate:"2007-12-03"},
				{id:"15",name:"Play Station",note:"note3",stock:"No", ship:"FedEx",sdate:"2007-12-03"},
				{id:"16",name:"Mobile Telephone",note:"note",stock:"Yes",ship:"ARAMEX",sdate:"2007-12-03"},
				{id:"17",name:"Server",note:"note2",stock:"Yes",ship:"TNT",sdate:"2007-12-03"},
				{id:"18",name:"Matrix Printer",note:"note3",stock:"No", ship:"FedEx",sdate:"2007-12-03"},
				{id:"19",name:"Matrix Printer",note:"note3",stock:"No", ship:"FedEx",sdate:"2007-12-03"},
				{id:"20",name:"Desktop Computer",note:"note",stock:"Yes",ship:"FedEx", sdate:"2007-12-03"},
				{id:"21",name:"Laptop",note:"Long text ",stock:"Yes",ship:"InTime",sdate:"2007-12-03"},
				{id:"22",name:"LCD Monitor",note:"note3",stock:"Yes",ship:"TNT",sdate:"2007-12-03"},
				{id:"23",name:"Speakers",note:"note",stock:"No",ship:"ARAMEX",sdate:"2007-12-03"}
			];
			
			var subgrid_data = 
			[
			 {id:"1", name:"sub grid item 1", qty: 11},
			 {id:"2", name:"sub grid item 2", qty: 3},
			 {id:"3", name:"sub grid item 3", qty: 12},
			 {id:"4", name:"sub grid item 4", qty: 5},
			 {id:"5", name:"sub grid item 5", qty: 2},
			 {id:"6", name:"sub grid item 6", qty: 9},
			 {id:"7", name:"sub grid item 7", qty: 3},
			 {id:"8", name:"sub grid item 8", qty: 8}
			];
			
			jQuery(function($) {
				var grid_selector = "#grid-table";
				var pager_selector = "#grid-pager";
				
				//resize to fit page size
				$(window).on('resize.jqGrid', function () {
					$(grid_selector).jqGrid( 'setGridWidth', $(".page-content").width() );
			    })
				//resize on sidebar collapse/expand
				var parent_column = $(grid_selector).closest('[class*="col-"]');
				$(document).on('settings.ace.jqGrid' , function(ev, event_name, collapsed) {
					if( event_name === 'sidebar_collapsed' || event_name === 'main_container_fixed' ) {
						//setTimeout is for webkit only to give time for DOM changes and then redraw!!!
						setTimeout(function() {
							$(grid_selector).jqGrid( 'setGridWidth', parent_column.width() );
						}, 0);
					}
			    })
				
				//if your grid is inside another element, for example a tab pane, you should use its parent's width:
				/**
				$(window).on('resize.jqGrid', function () {
					var parent_width = $(grid_selector).closest('.tab-pane').width();
					$(grid_selector).jqGrid( 'setGridWidth', parent_width );
				})
				//and also set width when tab pane becomes visible
				$('#myTab a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
				  if($(e.target).attr('href') == '#mygrid') {
					var parent_width = $(grid_selector).closest('.tab-pane').width();
					$(grid_selector).jqGrid( 'setGridWidth', parent_width );
				  }
				})
				*/
				
				
			
			
			
				jQuery(grid_selector).jqGrid({
					//direction: "rtl",
			
					//subgrid options
					subGrid : true,
					//subGridModel: [{ name : ['No','Item Name','Qty'], width : [55,200,80] }],
					//datatype: "xml",
					subGridOptions : {
						plusicon : "ace-icon fa fa-plus center bigger-110 blue",
						minusicon  : "ace-icon fa fa-minus center bigger-110 blue",
						openicon : "ace-icon fa fa-chevron-right center orange"
					},
					//for this example we are using local data
					subGridRowExpanded: function (subgridDivId, rowId) {
						var subgridTableId = subgridDivId + "_t";
						$("#" + subgridDivId).html("<table id='" + subgridTableId + "'></table>");
						$("#" + subgridTableId).jqGrid({
							datatype: 'local',
							data: subgrid_data,
							colNames: ['No','Item Name','Qty'],
							colModel: [
								{ name: 'id', width: 50 },
								{ name: 'name', width: 150 },
								{ name: 'qty', width: 50 }
							]
						});
					},
					
			
			
					data: grid_data,
					datatype: "local",
					height: 250,
					colNames:[' ', 'ID','INVOICE VALUE','TYPE', 'NCL CARD ID', 'TIMESTAMP','CONSUMER ID'],
					//colNames:[' ', 'ID','INVOICE VALUE','TYPE', 'NCL CARD ID', 'TIMESTAMP','CONSUMER ID','MERCHANT ID','STATUS','NCL POS ID'],    Sl No	
					
					colModel:[
						{name:'myac',index:'', width:80, fixed:true, sortable:false, resize:false,
							formatter:'actions', 
							formatoptions:{ 
								keys:true,
								//delbutton: false,//disable delete button
								
								delOptions:{recreateForm: true, beforeShowForm:beforeDeleteCallback},
								//editformbutton:true, editOptions:{recreateForm: true, beforeShowForm:beforeEditCallback}
							}
						},
						{name:'id',index:'id', width:60, sorttype:"int", editable: true},
						{name:'sdate',index:'sdate',width:90, editable:true, sorttype:"date",unformat: pickDate},
						{name:'name',index:'name', width:150,editable: true,editoptions:{size:"20",maxlength:"30"}},
						{name:'stock',index:'stock', width:70, editable: true,edittype:"checkbox",editoptions: {value:"Yes:No"},unformat: aceSwitch},
						{name:'ship',index:'ship', width:90, editable: true,edittype:"select",editoptions:{value:"FE:FedEx;IN:InTime;TN:TNT;AR:ARAMEX"}},
						{name:'note',index:'note', width:150, sortable:false,editable: true,edittype:"textarea", editoptions:{rows:"2",cols:"10"}} 
					], 
			
					viewrecords : true,
					rowNum:10,
					rowList:[10,20,30],
					pager : pager_selector,
					altRows: true,
					//toppager: true,
					
					multiselect: true,
					//multikey: "ctrlKey",
			        multiboxonly: true,
			
					loadComplete : function() {
						var table = this;
						setTimeout(function(){
							styleCheckbox(table);
							
							updateActionIcons(table);
							updatePagerIcons(table);
							enableTooltips(table);
						}, 0);
					},
			
					editurl: "/dummy.html",//nothing is saved
					caption: "jqGrid with inline editing"
			
					//,autowidth: true,
			
			
					/**
					,
					grouping:true, 
					groupingView : { 
						 groupField : ['name'],
						 groupDataSorted : true,
						 plusicon : 'fa fa-chevron-down bigger-110',
						 minusicon : 'fa fa-chevron-up bigger-110'
					},
					caption: "Grouping"
					*/
			
				});
				$(window).triggerHandler('resize.jqGrid');//trigger window resize to make the grid get the correct size
				
				
			
				//enable search/filter toolbar
				//jQuery(grid_selector).jqGrid('filterToolbar',{defaultSearch:true,stringResult:true})
				//jQuery(grid_selector).filterToolbar({});
			
			
				//switch element when editing inline
				function aceSwitch( cellvalue, options, cell ) {
					setTimeout(function(){
						$(cell) .find('input[type=checkbox]')
							.addClass('ace ace-switch ace-switch-5')
							.after('<span class="lbl"></span>');
					}, 0);
				}
				//enable datepicker
				function pickDate( cellvalue, options, cell ) {
					setTimeout(function(){
						$(cell) .find('input[type=text]')
								.datepicker({format:'yyyy-mm-dd' , autoclose:true}); 
					}, 0);
				}
			
			
				//navButtons
				jQuery(grid_selector).jqGrid('navGrid',pager_selector,
					{ 	//navbar options
						edit: true,
						editicon : 'ace-icon fa fa-pencil blue',
						add: true,
						addicon : 'ace-icon fa fa-plus-circle purple',
						del: true,
						delicon : 'ace-icon fa fa-trash-o red',
						search: true,
						searchicon : 'ace-icon fa fa-search orange',
						refresh: true,
						refreshicon : 'ace-icon fa fa-refresh green',
						view: true,
						viewicon : 'ace-icon fa fa-search-plus grey',
					},
					{
						//edit record form
						//closeAfterEdit: true,
						//width: 700,
						recreateForm: true,
						beforeShowForm : function(e) {
							var form = $(e[0]);
							form.closest('.ui-jqdialog').find('.ui-jqdialog-titlebar').wrapInner('<div class="widget-header" />')
							style_edit_form(form);
						}
					},
					{
						//new record form
						//width: 700,
						closeAfterAdd: true,
						recreateForm: true,
						viewPagerButtons: false,
						beforeShowForm : function(e) {
							var form = $(e[0]);
							form.closest('.ui-jqdialog').find('.ui-jqdialog-titlebar')
							.wrapInner('<div class="widget-header" />')
							style_edit_form(form);
						}
					},
					{
						//delete record form
						recreateForm: true,
						beforeShowForm : function(e) {
							var form = $(e[0]);
							if(form.data('styled')) return false;
							
							form.closest('.ui-jqdialog').find('.ui-jqdialog-titlebar').wrapInner('<div class="widget-header" />')
							style_delete_form(form);
							
							form.data('styled', true);
						},
						onClick : function(e) {
							//alert(1);
						}
					},
					{
						//search form
						recreateForm: true,
						afterShowSearch: function(e){
							var form = $(e[0]);
							form.closest('.ui-jqdialog').find('.ui-jqdialog-title').wrap('<div class="widget-header" />')
							style_search_form(form);
						},
						afterRedraw: function(){
							style_search_filters($(this));
						}
						,
						multipleSearch: true,
						/**
						multipleGroup:true,
						showQuery: true
						*/
					},
					{
						//view record form
						recreateForm: true,
						beforeShowForm: function(e){
							var form = $(e[0]);
							form.closest('.ui-jqdialog').find('.ui-jqdialog-title').wrap('<div class="widget-header" />')
						}
					}
				)
			
			
				
				function style_edit_form(form) {
					//enable datepicker on "sdate" field and switches for "stock" field
					form.find('input[name=sdate]').datepicker({format:'yyyy-mm-dd' , autoclose:true})
					
					form.find('input[name=stock]').addClass('ace ace-switch ace-switch-5').after('<span class="lbl"></span>');
							   //don't wrap inside a label element, the checkbox value won't be submitted (POST'ed)
							  //.addClass('ace ace-switch ace-switch-5').wrap('<label class="inline" />').after('<span class="lbl"></span>');
			
							
					//update buttons classes
					var buttons = form.next().find('.EditButton .fm-button');
					buttons.addClass('btn btn-sm').find('[class*="-icon"]').hide();//ui-icon, s-icon
					buttons.eq(0).addClass('btn-primary').prepend('<i class="ace-icon fa fa-check"></i>');
					buttons.eq(1).prepend('<i class="ace-icon fa fa-times"></i>')
					
					buttons = form.next().find('.navButton a');
					buttons.find('.ui-icon').hide();
					buttons.eq(0).append('<i class="ace-icon fa fa-chevron-left"></i>');
					buttons.eq(1).append('<i class="ace-icon fa fa-chevron-right"></i>');		
				}
			
				function style_delete_form(form) {
					var buttons = form.next().find('.EditButton .fm-button');
					buttons.addClass('btn btn-sm btn-white btn-round').find('[class*="-icon"]').hide();//ui-icon, s-icon
					buttons.eq(0).addClass('btn-danger').prepend('<i class="ace-icon fa fa-trash-o"></i>');
					buttons.eq(1).addClass('btn-default').prepend('<i class="ace-icon fa fa-times"></i>')
				}
				
				function style_search_filters(form) {
					form.find('.delete-rule').val('X');
					form.find('.add-rule').addClass('btn btn-xs btn-primary');
					form.find('.add-group').addClass('btn btn-xs btn-success');
					form.find('.delete-group').addClass('btn btn-xs btn-danger');
				}
				function style_search_form(form) {
					var dialog = form.closest('.ui-jqdialog');
					var buttons = dialog.find('.EditTable')
					buttons.find('.EditButton a[id*="_reset"]').addClass('btn btn-sm btn-info').find('.ui-icon').attr('class', 'ace-icon fa fa-retweet');
					buttons.find('.EditButton a[id*="_query"]').addClass('btn btn-sm btn-inverse').find('.ui-icon').attr('class', 'ace-icon fa fa-comment-o');
					buttons.find('.EditButton a[id*="_search"]').addClass('btn btn-sm btn-purple').find('.ui-icon').attr('class', 'ace-icon fa fa-search');
				}
				
				function beforeDeleteCallback(e) {
					var form = $(e[0]);
					if(form.data('styled')) return false;
					
					form.closest('.ui-jqdialog').find('.ui-jqdialog-titlebar').wrapInner('<div class="widget-header" />')
					style_delete_form(form);
					
					form.data('styled', true);
				}
				
				function beforeEditCallback(e) {
					var form = $(e[0]);
					form.closest('.ui-jqdialog').find('.ui-jqdialog-titlebar').wrapInner('<div class="widget-header" />')
					style_edit_form(form);
				}
			
			
			
				//it causes some flicker when reloading or navigating grid
				//it may be possible to have some custom formatter to do this as the grid is being created to prevent this
				//or go back to default browser checkbox styles for the grid
				function styleCheckbox(table) {
				/**
					$(table).find('input:checkbox').addClass('ace')
					.wrap('<label />')
					.after('<span class="lbl align-top" />')
			
			
					$('.ui-jqgrid-labels th[id*="_cb"]:first-child')
					.find('input.cbox[type=checkbox]').addClass('ace')
					.wrap('<label />').after('<span class="lbl align-top" />');
				*/
				}
				
			
				//unlike navButtons icons, action icons in rows seem to be hard-coded
				//you can change them like this in here if you want
				function updateActionIcons(table) {
					/**
					var replacement = 
					{
						'ui-ace-icon fa fa-pencil' : 'ace-icon fa fa-pencil blue',
						'ui-ace-icon fa fa-trash-o' : 'ace-icon fa fa-trash-o red',
						'ui-icon-disk' : 'ace-icon fa fa-check green',
						'ui-icon-cancel' : 'ace-icon fa fa-times red'
					};
					$(table).find('.ui-pg-div span.ui-icon').each(function(){
						var icon = $(this);
						var $class = $.trim(icon.attr('class').replace('ui-icon', ''));
						if($class in replacement) icon.attr('class', 'ui-icon '+replacement[$class]);
					})
					*/
				}
				
				//replace icons with FontAwesome icons like above
				function updatePagerIcons(table) {
					var replacement = 
					{
						'ui-icon-seek-first' : 'ace-icon fa fa-angle-double-left bigger-140',
						'ui-icon-seek-prev' : 'ace-icon fa fa-angle-left bigger-140',
						'ui-icon-seek-next' : 'ace-icon fa fa-angle-right bigger-140',
						'ui-icon-seek-end' : 'ace-icon fa fa-angle-double-right bigger-140'
					};
					$('.ui-pg-table:not(.navtable) > tbody > tr > .ui-pg-button > .ui-icon').each(function(){
						var icon = $(this);
						var $class = $.trim(icon.attr('class').replace('ui-icon', ''));
						
						if($class in replacement) icon.attr('class', 'ui-icon '+replacement[$class]);
					})
				}
			
				function enableTooltips(table) {
					$('.navtable .ui-pg-button').tooltip({container:'body'});
					$(table).find('.ui-pg-div').tooltip({container:'body'});
				}
			
				//var selr = jQuery(grid_selector).jqGrid('getGridParam','selrow');
			
				$(document).one('ajaxloadstart.page', function(e) {
					$(grid_selector).jqGrid('GridUnload');
					$('.ui-jqdialog').remove();
				});
			});
		</script>
		<script type="text/javascript">
			$(function () {
			$('#fromdate').datetimepicker();
			$('#todate').datetimepicker();
			});
		</script>-->
	</body>
</html>
