<?php
session_start();
unset($_SESSION["ID"]);
unset($_SESSION["EMAILID"]);
header("Location:login.php");
?>
