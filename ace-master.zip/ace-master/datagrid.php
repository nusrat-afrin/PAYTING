<?php
 
## +---------------------------------------------------------------------------+
## | 1. Creating & Calling:                                                    |
## +---------------------------------------------------------------------------+
##  *** define a relative (virtual) path to datagrid.class.php file
##  *** directory (relatively to the current file)
##  *** RELATIVE PATH ONLY ***
define ("DATAGRID_DIR", "datagrid/");                    
require_once(DATAGRID_DIR."datagrid.class.php");
 
##  *** creating variables that we need for database connection    
$DB_USER = "db_user";
$DB_PASS = "db_password";      
$DB_HOST = "db_host";      
$DB_NAME = "db_name";      
 
##  *** put a primary key on the first place
$sql=" SELECT
   demo_presidents.id,
   demo_presidents.region_id,
   demo_presidents.country_id,
   demo_presidents.name,
   demo_presidents.birth_date,
   demo_presidents.status,
   demo_presidents.rating,
   demo_countries.name as country_name
FROM demo_presidents
   INNER JOIN demo_countries ON demo_presidents.country_id=demo_countries.id ";
 
##  *** set needed options and create a new class instance
$debug_mode = false;        /* display SQL statements while processing */    
$messaging = true;          /* display system messages on a screen */
$unique_prefix = "prs_";    /* prevent overlays - must be started with a letter */
$dgrid = new DataGrid($debug_mode, $messaging, $unique_prefix);
 
##  *** set data source with needed options
$default_order = array("rating"=>"ASC");
$dgrid->DataSource("PDO", "mysql", $DB_HOST, $DB_NAME, $DB_USER, $DB_PASS, $sql, $default_order);            
$dgrid->isDemo = true;
$dgrid->navigationBar = "";
 
## +---------------------------------------------------------------------------+
## | 2. General Settings:                                                      |
## +---------------------------------------------------------------------------+
##  *** allow multirow operations
$multirow_option = true;
$dgrid->AllowMultirowOperations($multirow_option);
$multirow_operations = array(
    "edit"  => array("view"=>false),
    "delete"  => array("view"=>true),
    "details" => array("view"=>true),
);
$dgrid->SetMultirowOperations($multirow_operations);  
##  *** set DataGrid caption
$dg_caption = "Presidents";
$dgrid->SetCaption($dg_caption);
 
## +---------------------------------------------------------------------------+
## | 3. Printing & Exporting Settings:                                         |
## +---------------------------------------------------------------------------+
##  *** set printing option: true(default) or false
$printing_option = false;
$dgrid->AllowPrinting($printing_option);
 
## +---------------------------------------------------------------------------+
## | 4. Sorting & Paging Settings:                                             |
## +---------------------------------------------------------------------------+
##  *** set paging option: true(default) or false
$paging_option = true;
$rows_numeration = false;
$numeration_sign = "N #";
$dropdown_paging = true;
$dgrid->AllowPaging($paging_option, $rows_numeration, $numeration_sign, $dropdown_paging);
##  *** set paging settings
$bottom_paging = array("results"=>true, "results_align"=>"left", "pages"=>true, "pages_align"=>"center", "page_size"=>true, "page_size_align"=>"right");
$top_paging = array();
$pages_array = array("5"=>"5", "10"=>"10", "25"=>"25", "50"=>"50", "100"=>"100", "250"=>"250", "500"=>"500", "1000"=>"1000");
$default_page_size = 10;
$paging_arrows = array("first"=>"|&lt;&lt;", "previous"=>"&lt;&lt;", "next"=>"&gt;&gt;", "last"=>"&gt;&gt;|");
$dgrid->SetPagingSettings($bottom_paging, $top_paging, $pages_array, $default_page_size, $paging_arrows);
 
## +---------------------------------------------------------------------------+
## | 5. Filter Settings:                                                       |
## +---------------------------------------------------------------------------+
##  *** set filtering option: true or false(default)
$filtering_option = true;
$show_search_type = true;
$dgrid->AllowFiltering($filtering_option, $show_search_type);
##  *** set additional filtering settings
##  *** tips: use "," (comma) if you want to make search by some words, for ex.: hello, bye, hi
$filtering_fields = array(
    "<b>Country</b> <br />(start typing to see autocomplete in work)"=>array("type"=>"textbox", "autocomplete"=>"true", "handler"=>"autosuggest_countries.php", "maxresults"=>"12", "shownoresults"=>"true", "table"=>"demo_countries", "field"=>"name", "show_operator"=>"false", "default_operator"=>"like%", "case_sensitive"=>"false", "comparison_type"=>"string", "width"=>"", "on_js_event"=>""),
);
$dgrid->SetFieldsFiltering($filtering_fields);
 
## +---------------------------------------------------------------------------+
## | 6. View Mode Settings:                                                    |
## +---------------------------------------------------------------------------+
##  *** set view mode table properties
$vm_table_properties = array("width"=>"75%");
$dgrid->SetViewModeTableProperties($vm_table_properties);  
##  *** set columns in view mode
$vm_columns = array(
    "name" => array("header"=>"Name", "type"=>"label", "header_tooltip"=>"Name of President for specific country", "header_tooltip_type"=>"floating", "align"=>"left", "wrap"=>"wrap", "text_length"=>"20"),
    "birth_date" => array("header"=>"Birth Date", "type"=>"label", "align"=>"center", "wrap"=>"nowrap", "text_length"=>"-1"),
    "status" => array("header"=>"Status", "type"=>"label", "align"=>"center", "wrap"=>"nowrap", "text_length"=>"30"),
    "rating" => array("header"=>"Rating", "type"=>"label", "align"=>"center", "wrap"=>"nowrap", "text_length"=>"-1", "movable"=>"true"),
    "country_name" => array("header"=>"Country", "type"=>"label", "align"=>"center", "wrap"=>"nowrap", "text_length"=>"30", "sortable"=>"false")
);
$dgrid->SetColumnsInViewMode($vm_columns);
 
## +---------------------------------------------------------------------------+
## | 7. Add/Edit/Details Mode Settings:                                        |
## +---------------------------------------------------------------------------+
##  *** set add/edit mode table properties
$em_table_properties = array("width"=>"75%");
$dgrid->SetEditModeTableProperties($em_table_properties);
##  *** set details mode table properties
$dm_table_properties = array("width"=>"60%");
$dgrid->SetDetailsModeTableProperties($dm_table_properties);
##  ***  set settings for add/edit/details modes
$table_name  = "demo_presidents";
$primary_key = "id";
$condition   = "";
$dgrid->SetTableEdit($table_name, $primary_key, $condition);
##  *** set columns in edit mode    
$em_columns = array(
    "name" =>array("header"=>"Name", "type"=>"textbox", "width"=>"140px", "req_type"=>"rt"),
    "birth_date" =>array("header"=>"Birth Date", "type"=>"date", "req_type"=>"rt", "width"=>"80px", "readonly"=>"false", "maxlength"=>"-1", "default"=>"", "unique"=>"false", "unique_condition"=>"", "visible"=>"true", "on_js_event"=>"", "calendar_type"=>"floating"),
    "status" =>array("header"=>"Status", "type"=>"enum", "req_type"=>"st", "width"=>"210px", "readonly"=>false, "maxlength"=>"-1", "default"=>"", "unique"=>false, "unique_condition"=>"", "on_js_event"=>"", "source"=>"self", "view_type"=>"dropdownlist"),
    "rating" =>array("header"=>"Rating", "type"=>"textbox", "width"=>"100px", "req_type"=>"ri", "maxlength"=>"3"),
    "country_id" =>array("header"=>"Country", "type"=>"textbox", "width"=>"160px", "req_type"=>"ri", "readonly"=>true),      
);
$dgrid->SetColumnsInEditMode($em_columns);
##  *** set foreign keys for add/edit/details modes (if there are linked tables)
$foreign_keys = array(
    "country_id"=>array("table"=>"demo_countries", "field_key"=>"id", "field_name"=>"name", "view_type"=>"dropdownlist", "condition"=>"", "order_by_field"=>"", "order_type"=>"ASC", "on_js_event"=>""),
);
$dgrid->SetForeignKeysEdit($foreign_keys);
 
## +---------------------------------------------------------------------------+
## | 8. Bind the DataGrid:                                                     |
## +---------------------------------------------------------------------------+
##  *** bind the DataGrid and draw it on the screen
$dgrid->Bind();        
 
?>