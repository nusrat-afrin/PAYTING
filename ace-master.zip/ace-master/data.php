<?php

/* Left Join 
$query="Select ncl_transactions.TYPE,ncl_transactions.NCL_CARD_ID, ncl_transactions.TIMESTAMP, ncl_transactions.CONSUMER_ID, 
ncl_transactions.MERCHANT_ID, ncl_transactions.STATUS, ncl_transactions.NCL_POS_ID, ncl_invoices.INVOICE_VALUE
FROM  `ncl_transactions` LEFT JOIN  `ncl_invoices` ON ncl_transactions.INVOICE_ID = ncl_invoices.ID";*/
$query="Select ncl_transactions.TYPE,ncl_transactions.NCL_CARD_ID, ncl_transactions.TIMESTAMP, ncl_transactions.CONSUMER_ID, 
ncl_transactions.MERCHANT_ID, ncl_transactions.STATUS, ncl_transactions.NCL_POS_ID, ncl_invoices.INVOICE_VALUE
FROM  `ncl_transactions` LEFT JOIN  `ncl_invoices` ON ncl_transactions.INVOICE_ID = ncl_invoices.ID 
where ncl_transactions.TIMESTAMP > DATE_SUB(CURDATE(), INTERVAL 1 DAY) AND ncl_transactions.MERCHANT_ID=$_SESSION[ID]";

  if($_POST['today'] == 'Today')
  {
    ///do today's processing
    $today = date('Y-m-d',time());
    //echo $today;
    $query="Select ncl_transactions.TYPE,ncl_transactions.NCL_CARD_ID, ncl_transactions.TIMESTAMP, ncl_transactions.CONSUMER_ID, 
ncl_transactions.MERCHANT_ID, ncl_transactions.STATUS, ncl_transactions.NCL_POS_ID, ncl_invoices.INVOICE_VALUE
FROM  `ncl_transactions` LEFT JOIN  `ncl_invoices` ON ncl_transactions.INVOICE_ID = ncl_invoices.ID where 
ncl_transactions.TIMESTAMP='$today' AND ncl_transactions.MERCHANT_ID=$_SESSION[ID]";
//order by ID desc";
    //$query="select * from ncl_transactions where TIMESTAMP='$today' AND MERCHANT_ID=$_SESSION[ID] order by ID desc";
  }
  elseif($_POST['yesterday'] == 'Yesterday')
  {
    ///do yesterday's processing
    $m= date("m"); // Month value
    $de= date("d"); //today's date
    $y= date("Y"); // Year value
    $yesterday= date('Y-m-d', mktime(0,0,0,$m,($de-1),$y)); 
    //echo $yesterday;
    $query="Select ncl_transactions.TYPE,ncl_transactions.NCL_CARD_ID, ncl_transactions.TIMESTAMP, ncl_transactions.CONSUMER_ID, 
ncl_transactions.MERCHANT_ID, ncl_transactions.STATUS, ncl_transactions.NCL_POS_ID, ncl_invoices.INVOICE_VALUE
FROM  `ncl_transactions` LEFT JOIN  `ncl_invoices` ON ncl_transactions.INVOICE_ID = ncl_invoices.ID 
where ncl_transactions.TIMESTAMP='$yesterday' AND ncl_transactions.MERCHANT_ID=$_SESSION[ID]";
    //for($i=0; $i<=15; $i++){
    //echo date('Y-m-d',strtotime("$i day"))."<br>";
    //}
  }
  elseif($_POST['Last7Days'] == 'Last 7 Days')
  {
    ///do yesterday's processing
    $m= date("m"); // Month value
    $de= date("d"); //today's date
    $y= date("Y"); // Year value
    //$yesterday= date('Y-m-d', mktime(0,0,0,$m,($de-1),$y)); 
    //echo $yesterday;
    //$query="select * from ncl_transactions where TIMESTAMP='$yesterday' AND MERCHANT_ID=$_SESSION[ID] order by ID desc";
    //for($i=0; $i<=7; $i++)
    //{
      //echo date('Y-m-d',strtotime("$i day"))."<br>";
      $query="Select ncl_transactions.TYPE,ncl_transactions.NCL_CARD_ID, ncl_transactions.TIMESTAMP, ncl_transactions.CONSUMER_ID, 
ncl_transactions.MERCHANT_ID, ncl_transactions.STATUS, ncl_transactions.NCL_POS_ID, ncl_invoices.INVOICE_VALUE
FROM  `ncl_transactions` LEFT JOIN  `ncl_invoices` ON ncl_transactions.INVOICE_ID = ncl_invoices.ID where 
ncl_transactions.TIMESTAMP>= DATE_SUB(CURDATE(), INTERVAL 7 DAY) AND ncl_transactions.MERCHANT_ID=$_SESSION[ID]";


      //$query="select * from ncl_transactions where TIMESTAMP>= DATE_SUB(CURDATE(), INTERVAL 7 DAY) AND MERCHANT_ID=$_SESSION[ID] order by ID desc";
    //}
  }
  elseif($_POST['Last15Days'] == 'Last 15 Days')
  {
    ///do yesterday's processing
    $m= date("m"); // Month value
    $de= date("d"); //today's date
    $y= date("Y"); // Year value
    //$yesterday= date('Y-m-d', mktime(0,0,0,$m,($de-1),$y)); 
    //echo $yesterday;
    //$query="select * from ncl_transactions where TIMESTAMP='$yesterday' AND MERCHANT_ID=$_SESSION[ID] order by ID desc";
    //for($i=0; $i<=15; $i++)
    //{
      //echo date('Y-m-d',strtotime("$i day"))."<br>";
      $query="Select ncl_transactions.TYPE,ncl_transactions.NCL_CARD_ID, ncl_transactions.TIMESTAMP, ncl_transactions.CONSUMER_ID, 
ncl_transactions.MERCHANT_ID, ncl_transactions.STATUS, ncl_transactions.NCL_POS_ID, ncl_invoices.INVOICE_VALUE
FROM  `ncl_transactions` LEFT JOIN  `ncl_invoices` ON ncl_transactions.INVOICE_ID = ncl_invoices.ID where 
ncl_transactions.TIMESTAMP>= DATE_SUB(CURDATE(), INTERVAL 15 DAY) AND ncl_transactions.MERCHANT_ID=$_SESSION[ID]";
      //$query="select * from ncl_transactions where TIMESTAMP>= DATE_SUB(CURDATE(), INTERVAL 15 DAY) AND MERCHANT_ID=$_SESSION[ID] order by ID desc";
    //}
  }
  elseif($_POST['Last30Days'] == 'Last 30 Days')
  {
    ///do yesterday's processing
    $m= date("m"); // Month value
    $de= date("d"); //today's date
    $y= date("Y"); // Year value
    //$yesterday= date('Y-m-d', mktime(0,0,0,$m,($de-1),$y)); 
    //echo $yesterday;
    //$query="select * from ncl_transactions where TIMESTAMP='$yesterday' AND MERCHANT_ID=$_SESSION[ID] order by ID desc";
    //for($i=0; $i<=30; $i++)
    //{
      //echo date('Y-m-d',strtotime("$i day"))."<br>";
      $query="Select ncl_transactions.TYPE,ncl_transactions.NCL_CARD_ID, ncl_transactions.TIMESTAMP, ncl_transactions.CONSUMER_ID, 
ncl_transactions.MERCHANT_ID, ncl_transactions.STATUS, ncl_transactions.NCL_POS_ID, ncl_invoices.INVOICE_VALUE
FROM  `ncl_transactions` LEFT JOIN  `ncl_invoices` ON ncl_transactions.INVOICE_ID = ncl_invoices.ID where 
ncl_transactions.TIMESTAMP>= DATE_SUB(CURDATE(), INTERVAL 30 DAY) AND ncl_transactions.MERCHANT_ID=$_SESSION[ID]";
      //$query="select * from ncl_transactions where TIMESTAMP>= DATE_SUB(CURDATE(), INTERVAL 30 DAY) AND MERCHANT_ID=$_SESSION[ID] order by ID desc";
    //}
  }
  elseif($_POST['Last6Months'] == 'Last 6 Months')
  {
    ///do yesterday's processing
    $m= date("m"); // Month value
    $de= date("d"); //today's date
    $y= date("Y"); // Year value
    //$yesterday= date('Y-m-d', mktime(0,0,0,$m,($de-1),$y)); 
    //echo $yesterday;
    //$query="select * from ncl_transactions where TIMESTAMP='$yesterday' AND MERCHANT_ID=$_SESSION[ID] order by ID desc";
    //for($i=0; $i<=180; $i++)
    //{
      //echo date('Y-m-d',strtotime("$i day"))."<br>";
      $query="Select ncl_transactions.TYPE,ncl_transactions.NCL_CARD_ID, ncl_transactions.TIMESTAMP, ncl_transactions.CONSUMER_ID, 
ncl_transactions.MERCHANT_ID, ncl_transactions.STATUS, ncl_transactions.NCL_POS_ID, ncl_invoices.INVOICE_VALUE
FROM  `ncl_transactions` LEFT JOIN  `ncl_invoices` ON ncl_transactions.INVOICE_ID = ncl_invoices.ID where 
ncl_transactions.TIMESTAMP>= DATE_SUB(CURDATE(), INTERVAL 6 MONTH) AND ncl_transactions.MERCHANT_ID=$_SESSION[ID]";
      //$query="select * from ncl_transactions where TIMESTAMP>= DATE_SUB(CURDATE(), INTERVAL 6 MONTH) AND MERCHANT_ID=$_SESSION[ID] order by ID desc";
    //}
  }
  elseif($_POST['Last1Year'] == 'Last 1 Year')
  {
    ///do yesterday's processing
    $m= date("m"); // Month value
    $de= date("d"); //today's date
    $y= date("Y"); // Year value
    //$yesterday= date('Y-m-d', mktime(0,0,0,$m,($de-1),$y)); 
    //echo $yesterday;
    //$query="select * from ncl_transactions where TIMESTAMP='$yesterday' AND MERCHANT_ID=$_SESSION[ID] order by ID desc";
    //for($i=0; $i<=180; $i++)
    //{
      //echo date('Y-m-d',strtotime("$i day"))."<br>";
      $query="Select ncl_transactions.TYPE,ncl_transactions.NCL_CARD_ID, ncl_transactions.TIMESTAMP, ncl_transactions.CONSUMER_ID, 
ncl_transactions.MERCHANT_ID, ncl_transactions.STATUS, ncl_transactions.NCL_POS_ID, ncl_invoices.INVOICE_VALUE
FROM  `ncl_transactions` LEFT JOIN  `ncl_invoices` ON ncl_transactions.INVOICE_ID = ncl_invoices.ID where 
ncl_transactions.TIMESTAMP>= DATE_SUB(CURDATE(), INTERVAL 1 YEAR) AND ncl_transactions.MERCHANT_ID=$_SESSION[ID]";
      //$query="select * from ncl_transactions where TIMESTAMP>= DATE_SUB(CURDATE(), INTERVAL 1 YEAR) AND MERCHANT_ID=$_SESSION[ID] order by ID desc";
    //}
  }
  elseif($_POST['Last5Years'] == 'Last 5 Years')
  {
    ///do yesterday's processing
    $m= date("m"); // Month value
    $de= date("d"); //today's date
    $y= date("Y"); // Year value
    //$yesterday= date('Y-m-d', mktime(0,0,0,$m,($de-1),$y)); 
    //echo $yesterday;
    //$query="select * from ncl_transactions where TIMESTAMP='$yesterday' AND MERCHANT_ID=$_SESSION[ID] order by ID desc";
    //for($i=0; $i<=180; $i++)
    //{
      //echo date('Y-m-d',strtotime("$i day"))."<br>";
      $query="Select ncl_transactions.TYPE,ncl_transactions.NCL_CARD_ID, ncl_transactions.TIMESTAMP, ncl_transactions.CONSUMER_ID, 
ncl_transactions.MERCHANT_ID, ncl_transactions.STATUS, ncl_transactions.NCL_POS_ID, ncl_invoices.INVOICE_VALUE
FROM  `ncl_transactions` LEFT JOIN  `ncl_invoices` ON ncl_transactions.INVOICE_ID = ncl_invoices.ID where 
ncl_transactions.TIMESTAMP>= DATE_SUB(CURDATE(), INTERVAL 5 YEAR) AND ncl_transactions.MERCHANT_ID=$_SESSION[ID]";
      //$query="select * from ncl_transactions where TIMESTAMP>= DATE_SUB(CURDATE(), INTERVAL 5 YEAR) AND MERCHANT_ID=$_SESSION[ID] order by ID desc";
    //}
  }
  elseif($_POST['Search'] == 'Search')
  {
    /*Date Range*/
    $fromdate=$_POST['from'];
    $todate=$_POST['to'];
    //echo "$fromdate"."&nbsp;"."$todate";
    //$query="select * from ncl_transactions where MERCHANT_ID=$_SESSION[ID] order by ID desc";
    if($fromdate!='' && $todate!='')
    {
      $query="Select ncl_transactions.TYPE,ncl_transactions.NCL_CARD_ID, ncl_transactions.TIMESTAMP, ncl_transactions.CONSUMER_ID, 
ncl_transactions.MERCHANT_ID, ncl_transactions.STATUS, ncl_transactions.NCL_POS_ID, ncl_invoices.INVOICE_VALUE
FROM  `ncl_transactions` LEFT JOIN  `ncl_invoices` ON ncl_transactions.INVOICE_ID = ncl_invoices.ID where 
ncl_transactions.TIMESTAMP BETWEEN '$fromdate' AND '$todate' AND ncl_transactions.MERCHANT_ID=$_SESSION[ID]";
      //$query="select * from ncl_transactions where TIMESTAMP BETWEEN '$fromdate' AND '$todate' AND MERCHANT_ID=$_SESSION[ID] order by ID desc";
    }
    else
    {
      echo "<br>"."Please Choose Both From & To Dates!!!!";
    }  
  }

/*$result=mysql_query($sql);
$num=mysql_num_rows($result);//if (mysql_num_rows($result) > 0) {
//echo "<br>"."$result";
//echo "<br>"."Number Of Rows:"."$num";

//INSERT INTO `dev_payting`.`ncl_transactions` (`ID`, `TYPE`, `INVOICE_ID`, `NCL_CARD_ID`, `TIMESTAMP`, `CONSUMER_ID`, `MERCHANT_ID`, `STATUS`, `NCL_POS_ID`) VALUES ('2', '2', '2', '2', '2', '2', '2', '1', '2');
if($num==0)
{
  echo "<br>"."No Record Found!";
}
else
{
  echo strtoupper("Transaction Record");
  $i=0;

  while($row=mysql_fetch_array($result)){
 echo ++$i;//$row[0];?></td>
    <td><?php echo $row['INVOICE_VALUE'];?></td>
    <td><?php echo $row['TYPE'];?></td>
    <td><?php echo $row['NCL_CARD_ID'];?></td>
    <td><?php echo $row['TIMESTAMP'];?></td>
    <td><?php echo $row['CONSUMER_ID'];?></td>
    <td><?php echo $row['MERCHANT_ID'];?></td>
    <td><?php echo $row['STATUS'];?></td>
    <td><?php echo $row['NCL_POS_ID'];?></td>*/

// get data and store in a json array
//$from = 0;
//$to = 30;
//$query = "SELECT CompanyName, ContactName, ContactTitle, Address, City FROM customers LIMIT ?,?";

  $result = $mysqli->prepare($query);
  //$result->bind_param('ii', $from, $to);
  $result->execute();
  /* bind result variables */
  $result->bind_result($INVOICE_VALUE, $TYPE, $NCL_CARD_ID, $TIMESTAMP, $CONSUMER_ID,$MERCHANT_ID,$STATUS,$NCL_POS_ID);
  /* fetch values */
  while ($result->fetch())
    {
    $customers[] = array(
      'INVOICE_VALUE' => $INVOICE_VALUE,
      'TYPE' => $TYPE,
      'NCL_CARD_ID' => $NCL_CARD_ID,
      'TIMESTAMP' => $TIMESTAMP,
      'CONSUMER_ID' => $CONSUMER_ID,
      'MERCHANT_ID' => $MERCHANT_ID,
      'STATUS' => $STATUS,
      'NCL_POS_ID' => $NCL_POS_ID
    
    );
    }
  echo json_encode($customers);
  /* close statement */
  $result->close();
  /* close connection */
  //$mysqli->close();
  ?>

