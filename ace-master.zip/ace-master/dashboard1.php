<?php
session_start();
$conn = mysql_connect("localhost","root","password");
//$conn = mysql_connect("http://192.168.1.6:83","root","");
//mysql_select_db("dev_payting",$conn);
mysql_select_db("dev_payting",$conn);
?>
<html>
<head>
<title>Merchant Dashboard</title>
<link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
<script src="//code.jquery.com/jquery-1.10.2.js"></script>
<link rel="stylesheet" type="text/css" href="assets/css/styles.css" />
<script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
<link rel="stylesheet" type="text/css" href="assets/css/tcal.css" />
<script type="text/javascript" src="assets/js/tcal.js"></script>
<script src="https://code.jquery.com/jquery-2.0.2.min.js" integrity="sha256-TZWGoHXwgqBP1AF4SZxHIBKzUdtMGk0hCQegiR99itk=" crossorigin="anonymous"></script>
<!--
  <link rel="stylesheet" href="/resources/demos/style.css">
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script> -->
  <!--<script>
  $(function() {
    $( "#fromdate" ).datepicker();
    $( "#todate" ).datepicker();
  });
  </script>-->
  <script type="text/javascript">
    function printData()
    {
       alert(Hi);
       var divToPrint=document.getElementById("printTable");
       newWin= window.open("");
       newWin.document.write(divToPrint.outerHTML);
       newWin.print();
       newWin.close();
    }

    $('button').on('click',function(){
    printData();
    })
  </script>
  <script type="text/javascript"> 
    function Today() 
    { 
      var today = new Date();
      alert(today); 
    }
    function Yesterday() 
    {       
      var yesterday = new Date();
      yesterday ; //# => Fri Apr 01 2011 11:14:50 GMT+0200 (CEST)
      yesterday.setDate(yesterday.getDate() - 1);
      yesterday ; //# => Thu Mar 31 2011 11:14:50 GMT+0200 (CEST)
      alert(yesterday);
      /*var today = new Date();
      //subtract milliseconds representing one day from current date
      //var yesterday = new Date(today - 24*60*60*1000);
      var yesterday = today-1;//today.setDate(today.getDate()-1);
      alert(yesterday); */
    }
    function Search() 
    {       
      var from = document.getElementById("from");
      alert(from);


    }
  </script>
</head>
<body>
<table border="0" class="table" cellpadding="10" cellspacing="1" width="100%" align="center" bgcolor="#FFFFFF">
<tr class="tableheader">
<td align="center">
<?php echo strtoupper("Merchant Dashboard");?>
<p align="right">
<?php echo strtoupper("Welcome");?>&nbsp;
<?php 
$result = mysql_query("SELECT * FROM ncl_merchant_users where ID=$_SESSION[ID]");
//echo "SELECT * FROM ncl_merchant_users where ID=$_SESSION[ID]";
$row  = mysql_fetch_array($result);
//echo "<br>"."$row";
echo strtoupper($row["NAME"]);
//echo $_SESSION["EMAILID"]."<br>".$row["NAME"]."<br>".$_SESSION["ID"]."<br>".ucwords($_SESSION["NAME"])."<br>"; ?>!
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<a href="logout.php" tite="Logout">Logout</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p></td>
</tr>
<tr class="">
<td align="center">
<?php
if($_SESSION["ID"]) {
?>

<form action="dashboard.php" method="post">
<input type="submit" name="today" id="today" value="Today"> <!--onclick="Today()"-->&nbsp;&nbsp;
<input type="submit" name="yesterday" id="yesterday" value="Yesterday">  <!--onclick="Yesterday()"-->&nbsp;&nbsp;
<input type="submit" name="Last7Days" id="Last7Days" value="Last 7 Days" ><!--onclick="Last7Days()"-->&nbsp;&nbsp;
<input type="submit" name="Last15Days" id="Last15Days" value="Last 15 Days"><!--onclick="Last15Days()"-->&nbsp;&nbsp;
<input type="submit" name="Last30Days" id="Last30Days" value="Last 30 Days"><!-- onclick="Last7Days()"-->&nbsp;&nbsp;
<input type="submit" name="Last6Months" id="Last6Months" value="Last 6 Months"><!-- onclick="Last6Months()"-->&nbsp;&nbsp;
<input type="submit" name="Last1Year" id="Last1Year" value="Last 1 Year"><!-- onclick="LastYear()"-->&nbsp;&nbsp;
<input type="submit" name="Last5Years" id="Last5Years" value="Last 5 Years"><!-- onclick="Last5Years()"--><br><br>
From Date: <input name="from" id="from" type="text" class="tcal"/>
To Date: <input name="to" id="to" type="text" class="tcal"/>
<input name="Search" id="Search" type="submit" value="Search" onclick="Search()"/>&nbsp;&nbsp;&nbsp;&nbsp;
<a href="##" onclick="window.print()">Print</a>
</form>

<!--
From Date : <input type="text" id="fromdate" name="fromdate">
To Date : <input type="text" id="todate" name="todate">-->
<?php
//if (!isset($_POST['submit']))
//{
 
/* Left Join 
$sql="Select ncl_transactions.TYPE,ncl_transactions.NCL_CARD_ID, ncl_transactions.TIMESTAMP, ncl_transactions.CONSUMER_ID, 
ncl_transactions.MERCHANT_ID, ncl_transactions.STATUS, ncl_transactions.NCL_POS_ID, ncl_invoices.INVOICE_VALUE
FROM  `ncl_transactions` LEFT JOIN  `ncl_invoices` ON ncl_transactions.INVOICE_ID = ncl_invoices.ID";*/
$sql="Select ncl_transactions.TYPE,ncl_transactions.NCL_CARD_ID, ncl_transactions.TIMESTAMP, ncl_transactions.CONSUMER_ID, 
ncl_transactions.MERCHANT_ID, ncl_transactions.STATUS, ncl_transactions.NCL_POS_ID, ncl_invoices.INVOICE_VALUE
FROM  `ncl_transactions` LEFT JOIN  `ncl_invoices` ON ncl_transactions.INVOICE_ID = ncl_invoices.ID 
where ncl_transactions.TIMESTAMP > DATE_SUB(CURDATE(), INTERVAL 1 DAY) AND ncl_transactions.MERCHANT_ID=$_SESSION[ID]";

  if($_POST['today'] == 'Today')
  {
    ///do today's processing
    $today = date('Y-m-d',time());
    //echo $today;
    $sql="Select ncl_transactions.TYPE,ncl_transactions.NCL_CARD_ID, ncl_transactions.TIMESTAMP, ncl_transactions.CONSUMER_ID, 
ncl_transactions.MERCHANT_ID, ncl_transactions.STATUS, ncl_transactions.NCL_POS_ID, ncl_invoices.INVOICE_VALUE
FROM  `ncl_transactions` LEFT JOIN  `ncl_invoices` ON ncl_transactions.INVOICE_ID = ncl_invoices.ID where 
ncl_transactions.TIMESTAMP='$today' AND ncl_transactions.MERCHANT_ID=$_SESSION[ID]";
//order by ID desc";
    //$sql="select * from ncl_transactions where TIMESTAMP='$today' AND MERCHANT_ID=$_SESSION[ID] order by ID desc";
  }
  elseif($_POST['yesterday'] == 'Yesterday')
  {
    ///do yesterday's processing
    $m= date("m"); // Month value
    $de= date("d"); //today's date
    $y= date("Y"); // Year value
    $yesterday= date('Y-m-d', mktime(0,0,0,$m,($de-1),$y)); 
    //echo $yesterday;
    $sql="Select ncl_transactions.TYPE,ncl_transactions.NCL_CARD_ID, ncl_transactions.TIMESTAMP, ncl_transactions.CONSUMER_ID, 
ncl_transactions.MERCHANT_ID, ncl_transactions.STATUS, ncl_transactions.NCL_POS_ID, ncl_invoices.INVOICE_VALUE
FROM  `ncl_transactions` LEFT JOIN  `ncl_invoices` ON ncl_transactions.INVOICE_ID = ncl_invoices.ID 
where ncl_transactions.TIMESTAMP='$yesterday' AND ncl_transactions.MERCHANT_ID=$_SESSION[ID]";
    //for($i=0; $i<=15; $i++){
    //echo date('Y-m-d',strtotime("$i day"))."<br>";
    //}
  }
  elseif($_POST['Last7Days'] == 'Last 7 Days')
  {
    ///do yesterday's processing
    $m= date("m"); // Month value
    $de= date("d"); //today's date
    $y= date("Y"); // Year value
    //$yesterday= date('Y-m-d', mktime(0,0,0,$m,($de-1),$y)); 
    //echo $yesterday;
    //$sql="select * from ncl_transactions where TIMESTAMP='$yesterday' AND MERCHANT_ID=$_SESSION[ID] order by ID desc";
    //for($i=0; $i<=7; $i++)
    //{
      //echo date('Y-m-d',strtotime("$i day"))."<br>";
      $sql="Select ncl_transactions.TYPE,ncl_transactions.NCL_CARD_ID, ncl_transactions.TIMESTAMP, ncl_transactions.CONSUMER_ID, 
ncl_transactions.MERCHANT_ID, ncl_transactions.STATUS, ncl_transactions.NCL_POS_ID, ncl_invoices.INVOICE_VALUE
FROM  `ncl_transactions` LEFT JOIN  `ncl_invoices` ON ncl_transactions.INVOICE_ID = ncl_invoices.ID where 
ncl_transactions.TIMESTAMP>= DATE_SUB(CURDATE(), INTERVAL 7 DAY) AND ncl_transactions.MERCHANT_ID=$_SESSION[ID]";


      //$sql="select * from ncl_transactions where TIMESTAMP>= DATE_SUB(CURDATE(), INTERVAL 7 DAY) AND MERCHANT_ID=$_SESSION[ID] order by ID desc";
    //}
  }
  elseif($_POST['Last15Days'] == 'Last 15 Days')
  {
    ///do yesterday's processing
    $m= date("m"); // Month value
    $de= date("d"); //today's date
    $y= date("Y"); // Year value
    //$yesterday= date('Y-m-d', mktime(0,0,0,$m,($de-1),$y)); 
    //echo $yesterday;
    //$sql="select * from ncl_transactions where TIMESTAMP='$yesterday' AND MERCHANT_ID=$_SESSION[ID] order by ID desc";
    //for($i=0; $i<=15; $i++)
    //{
      //echo date('Y-m-d',strtotime("$i day"))."<br>";
      $sql="Select ncl_transactions.TYPE,ncl_transactions.NCL_CARD_ID, ncl_transactions.TIMESTAMP, ncl_transactions.CONSUMER_ID, 
ncl_transactions.MERCHANT_ID, ncl_transactions.STATUS, ncl_transactions.NCL_POS_ID, ncl_invoices.INVOICE_VALUE
FROM  `ncl_transactions` LEFT JOIN  `ncl_invoices` ON ncl_transactions.INVOICE_ID = ncl_invoices.ID where 
ncl_transactions.TIMESTAMP>= DATE_SUB(CURDATE(), INTERVAL 15 DAY) AND ncl_transactions.MERCHANT_ID=$_SESSION[ID]";
      //$sql="select * from ncl_transactions where TIMESTAMP>= DATE_SUB(CURDATE(), INTERVAL 15 DAY) AND MERCHANT_ID=$_SESSION[ID] order by ID desc";
    //}
  }
  elseif($_POST['Last30Days'] == 'Last 30 Days')
  {
    ///do yesterday's processing
    $m= date("m"); // Month value
    $de= date("d"); //today's date
    $y= date("Y"); // Year value
    //$yesterday= date('Y-m-d', mktime(0,0,0,$m,($de-1),$y)); 
    //echo $yesterday;
    //$sql="select * from ncl_transactions where TIMESTAMP='$yesterday' AND MERCHANT_ID=$_SESSION[ID] order by ID desc";
    //for($i=0; $i<=30; $i++)
    //{
      //echo date('Y-m-d',strtotime("$i day"))."<br>";
      $sql="Select ncl_transactions.TYPE,ncl_transactions.NCL_CARD_ID, ncl_transactions.TIMESTAMP, ncl_transactions.CONSUMER_ID, 
ncl_transactions.MERCHANT_ID, ncl_transactions.STATUS, ncl_transactions.NCL_POS_ID, ncl_invoices.INVOICE_VALUE
FROM  `ncl_transactions` LEFT JOIN  `ncl_invoices` ON ncl_transactions.INVOICE_ID = ncl_invoices.ID where 
ncl_transactions.TIMESTAMP>= DATE_SUB(CURDATE(), INTERVAL 30 DAY) AND ncl_transactions.MERCHANT_ID=$_SESSION[ID]";
      //$sql="select * from ncl_transactions where TIMESTAMP>= DATE_SUB(CURDATE(), INTERVAL 30 DAY) AND MERCHANT_ID=$_SESSION[ID] order by ID desc";
    //}
  }
  elseif($_POST['Last6Months'] == 'Last 6 Months')
  {
    ///do yesterday's processing
    $m= date("m"); // Month value
    $de= date("d"); //today's date
    $y= date("Y"); // Year value
    //$yesterday= date('Y-m-d', mktime(0,0,0,$m,($de-1),$y)); 
    //echo $yesterday;
    //$sql="select * from ncl_transactions where TIMESTAMP='$yesterday' AND MERCHANT_ID=$_SESSION[ID] order by ID desc";
    //for($i=0; $i<=180; $i++)
    //{
      //echo date('Y-m-d',strtotime("$i day"))."<br>";
      $sql="Select ncl_transactions.TYPE,ncl_transactions.NCL_CARD_ID, ncl_transactions.TIMESTAMP, ncl_transactions.CONSUMER_ID, 
ncl_transactions.MERCHANT_ID, ncl_transactions.STATUS, ncl_transactions.NCL_POS_ID, ncl_invoices.INVOICE_VALUE
FROM  `ncl_transactions` LEFT JOIN  `ncl_invoices` ON ncl_transactions.INVOICE_ID = ncl_invoices.ID where 
ncl_transactions.TIMESTAMP>= DATE_SUB(CURDATE(), INTERVAL 6 MONTH) AND ncl_transactions.MERCHANT_ID=$_SESSION[ID]";
      //$sql="select * from ncl_transactions where TIMESTAMP>= DATE_SUB(CURDATE(), INTERVAL 6 MONTH) AND MERCHANT_ID=$_SESSION[ID] order by ID desc";
    //}
  }
  elseif($_POST['Last1Year'] == 'Last 1 Year')
  {
    ///do yesterday's processing
    $m= date("m"); // Month value
    $de= date("d"); //today's date
    $y= date("Y"); // Year value
    //$yesterday= date('Y-m-d', mktime(0,0,0,$m,($de-1),$y)); 
    //echo $yesterday;
    //$sql="select * from ncl_transactions where TIMESTAMP='$yesterday' AND MERCHANT_ID=$_SESSION[ID] order by ID desc";
    //for($i=0; $i<=180; $i++)
    //{
      //echo date('Y-m-d',strtotime("$i day"))."<br>";
      $sql="Select ncl_transactions.TYPE,ncl_transactions.NCL_CARD_ID, ncl_transactions.TIMESTAMP, ncl_transactions.CONSUMER_ID, 
ncl_transactions.MERCHANT_ID, ncl_transactions.STATUS, ncl_transactions.NCL_POS_ID, ncl_invoices.INVOICE_VALUE
FROM  `ncl_transactions` LEFT JOIN  `ncl_invoices` ON ncl_transactions.INVOICE_ID = ncl_invoices.ID where 
ncl_transactions.TIMESTAMP>= DATE_SUB(CURDATE(), INTERVAL 1 YEAR) AND ncl_transactions.MERCHANT_ID=$_SESSION[ID]";
      //$sql="select * from ncl_transactions where TIMESTAMP>= DATE_SUB(CURDATE(), INTERVAL 1 YEAR) AND MERCHANT_ID=$_SESSION[ID] order by ID desc";
    //}
  }
  elseif($_POST['Last5Years'] == 'Last 5 Years')
  {
    ///do yesterday's processing
    $m= date("m"); // Month value
    $de= date("d"); //today's date
    $y= date("Y"); // Year value
    //$yesterday= date('Y-m-d', mktime(0,0,0,$m,($de-1),$y)); 
    //echo $yesterday;
    //$sql="select * from ncl_transactions where TIMESTAMP='$yesterday' AND MERCHANT_ID=$_SESSION[ID] order by ID desc";
    //for($i=0; $i<=180; $i++)
    //{
      //echo date('Y-m-d',strtotime("$i day"))."<br>";
      $sql="Select ncl_transactions.TYPE,ncl_transactions.NCL_CARD_ID, ncl_transactions.TIMESTAMP, ncl_transactions.CONSUMER_ID, 
ncl_transactions.MERCHANT_ID, ncl_transactions.STATUS, ncl_transactions.NCL_POS_ID, ncl_invoices.INVOICE_VALUE
FROM  `ncl_transactions` LEFT JOIN  `ncl_invoices` ON ncl_transactions.INVOICE_ID = ncl_invoices.ID where 
ncl_transactions.TIMESTAMP>= DATE_SUB(CURDATE(), INTERVAL 5 YEAR) AND ncl_transactions.MERCHANT_ID=$_SESSION[ID]";
      //$sql="select * from ncl_transactions where TIMESTAMP>= DATE_SUB(CURDATE(), INTERVAL 5 YEAR) AND MERCHANT_ID=$_SESSION[ID] order by ID desc";
    //}
  }
  elseif($_POST['Search'] == 'Search')
  {
    /*Date Range*/
    $fromdate=$_POST['from'];
    $todate=$_POST['to'];
    //echo "$fromdate"."&nbsp;"."$todate";
    //$sql="select * from ncl_transactions where MERCHANT_ID=$_SESSION[ID] order by ID desc";
    if($fromdate!='' && $todate!='')
    {
      $sql="Select ncl_transactions.TYPE,ncl_transactions.NCL_CARD_ID, ncl_transactions.TIMESTAMP, ncl_transactions.CONSUMER_ID, 
ncl_transactions.MERCHANT_ID, ncl_transactions.STATUS, ncl_transactions.NCL_POS_ID, ncl_invoices.INVOICE_VALUE
FROM  `ncl_transactions` LEFT JOIN  `ncl_invoices` ON ncl_transactions.INVOICE_ID = ncl_invoices.ID where 
ncl_transactions.TIMESTAMP BETWEEN '$fromdate' AND '$todate' AND ncl_transactions.MERCHANT_ID=$_SESSION[ID]";
      //$sql="select * from ncl_transactions where TIMESTAMP BETWEEN '$fromdate' AND '$todate' AND MERCHANT_ID=$_SESSION[ID] order by ID desc";
    }
    else
    {
      echo "<br>"."Please Choose Both From & To Dates!!!!";
    }  
  }



//$sql="select * from ncl_transactions where TIMESTAMP>= DATE_SUB(NOW(), INTERVAL 1 DAY) AND MERCHANT_ID=$_SESSION[ID] order by ID desc";       
//$sql="select * from ncl_transactions where TIMESTAMP>= DATE_SUB(NOW(), INTERVAL 2 DAY) AND MERCHANT_ID=$_SESSION[ID] order by ID desc";       
//$sql="select * from ncl_transactions where TIMESTAMP>= DATE_SUB(NOW(), INTERVAL 1 WEEK) AND MERCHANT_ID=$_SESSION[ID] order by ID desc";
//$sql="select * from ncl_transactions where TIMESTAMP>= DATE_SUB(NOW(), INTERVAL 1 MONTH) AND MERCHANT_ID=$_SESSION[ID] order by ID desc";
//$sql="select * from ncl_transactions where TIMESTAMP>= DATE_SUB(NOW(), INTERVAL 6 MONTH) AND MERCHANT_ID=$_SESSION[ID] order by ID desc";
//$sql="select * from ncl_transactions where TIMESTAMP>= DATE_SUB(NOW(), INTERVAL 10 YEAR) AND MERCHANT_ID=$_SESSION[ID] order by ID desc";
//$sql="select * from ncl_transactions where TIMESTAMP>= DATE_SUB(CURDATE(), INTERVAL 7 DAY) AND MERCHANT_ID=$_SESSION[ID] order by ID desc";
//$sql="select * from ncl_transactions where TIMESTAMP='$yesterday' AND MERCHANT_ID=$_SESSION[ID] order by ID desc";
//echo "<br>"."$sql";
$result=mysql_query($sql);
$num=mysql_num_rows($result);//if (mysql_num_rows($result) > 0) {
//echo "<br>"."$result";
//echo "<br>"."Number Of Rows:"."$num";

//INSERT INTO `dev_payting`.`ncl_transactions` (`ID`, `TYPE`, `INVOICE_ID`, `NCL_CARD_ID`, `TIMESTAMP`, `CONSUMER_ID`, `MERCHANT_ID`, `STATUS`, `NCL_POS_ID`) VALUES ('2', '2', '2', '2', '2', '2', '2', '1', '2');
?>
<tr>
<td class="table">
<table class="table" cellpadding="10" cellspacing="1" width="100%" height="100%" align="center" id="printTable">
<tr class="tableheader">
<?php 
      if($num==0)
      {
        echo "<br>"."No Record Found!";
      }
      else
      {
        echo strtoupper("Transaction Record");
?>

<th>Sl No</th>
<th>INVOICE VALUE</th>
<th>TYPE</th>
<th>NCL CARD ID</th>
<th>TIMESTAMP</th>
<th>CONSUMER ID</th>
<th>MERCHANT ID</th>
<th>STATUS</th>
<th>NCL POS ID</th>
</tr>
<?php 
$i=0;

while($row=mysql_fetch_array($result)){
//while ($i < $row) {
//while ($row=mysql_fetch_array($result)) {
//while($row)// = mysql_fetch_assoc($result))
//
  //if($row[]!=0){
 // for($1=1;$i<$num;$i++){
	?>
<tr class="tablerow2">
<?php ?>
	<td><?php echo ++$i;//$row[0];?></td>
  <td><?php echo $row['INVOICE_VALUE'];?></td>
	<td><?php echo $row['TYPE'];?></td>
	<td><?php echo $row['NCL_CARD_ID'];?></td>
  <td><?php echo $row['TIMESTAMP'];?></td>
  <td><?php echo $row['CONSUMER_ID'];?></td>
  <td><?php echo $row['MERCHANT_ID'];?></td>
  <td><?php echo $row['STATUS'];?></td>
  <td><?php echo $row['NCL_POS_ID'];?></td>
</tr>
<?php
//}
//else{
  //echo "No Record Found!";
//}
//$i++;
}
}
//}



}

?>
</table>
<!--<button onclick="()">Print</button>-->
</td>
</tr>
</td>
</tr>
</table>
</body></html>
